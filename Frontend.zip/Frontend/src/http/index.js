/* eslint-disable import/prefer-default-export */
import axios from './axios/axios_main';

export { axios };
