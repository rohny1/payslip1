import React from 'react'

const NoData = () => {
  return (
    <div>No Data Found</div>
  )
}

export default NoData