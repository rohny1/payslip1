import React, { useState, useEffect } from "react";
// import Modal from "../../components/common/Modal";
import Modals from "../../components/common/Modal";
import TableComponent from "../../components/tableComponent/TableComponent";
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Typography,
} from "@mui/material";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import { Card, Form, Modal } from "react-bootstrap";
import {
  AiOutlineFile,
  AiOutlineFileImage,
  AiOutlineFilePdf,
  AiOutlineFileText,
} from "react-icons/ai";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import {
  getAllAuctionCenterAction,
  createAuctionCenterAction,
  getAuctionCenterByIdAction,
  updateAuctionCenterAction,
} from "../../store/actions";

function CreateAuctionCenter({ open, setOpen }) {
  const getAllAuctionCenterList = useSelector(
    (state) => state.auctionCenter.getAllAuctionCenter.responseData
  );

  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [auctionCenterName, setAuctionCenterName] = useState("");
  const [auctionCenterCode, setAuctionCenterCode] = useState("");
  const [certificateNo, setCertificateNo] = useState("");
  const [editingAuctionCenterData, setEditingAuctionCenterData] =
    useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const newAuctionCenterData = {
      auctionCenterName: auctionCenterName,
      auctionCenterCode: auctionCenterCode,
      certificateNo: certificateNo,
      sessionUserId: 1,
      userId: 1,
      isActive: 1,
      stateId: 1,
    };
    try {
      if (editingAuctionCenterData) {
        editingAuctionCenterData.userId = 1;
        dispatch(updateAuctionCenterAction(editingAuctionCenterData));
      } else {
        dispatch(createAuctionCenterAction(newAuctionCenterData));
      }
      setAuctionCenterName("");
      setAuctionCenterCode("");
      setCertificateNo("");
      setEditingAuctionCenterData(null);
      setExpanded("panel2");
    } catch (error) {}
  };

  const handleEditClick = (auctionCenterId) => {
    // Call the action creator to get the auction center data by ID
    dispatch(getAuctionCenterByIdAction(auctionCenterId));
    setExpanded("panel1"); // Show the first accordion panel
  };

  const editingAuctionCenterDataFromState = useSelector(
    (state) => state.auctionCenter.auctionCenterById.responseData
    // .auctionCenter.auctionCenterById.responseData
  );

  useEffect(() => {
    if (editingAuctionCenterDataFromState) {
      setEditingAuctionCenterData(editingAuctionCenterDataFromState);
    } else {
      setEditingAuctionCenterData(null);
      dispatch(getAllAuctionCenterAction());
    }
  }, [editingAuctionCenterDataFromState]);

  const [expanded, setExpanded] = React.useState("panel1");
  const [showmodal, setShowmodal] = useState(false);
  const handleCloseHistory = () => setShowmodal(false);
  const [uploadedFiles, setUploadedFiles] = useState([]);
  const handleChange = (panel) => (event, isExpanded) => {
    setExpanded(isExpanded ? panel : false);
  };

  const [rows, setRows] = useState(getAllAuctionCenterList);
  useEffect(() => {
    setRows(getAllAuctionCenterList); // Update rows when getAllAuctionCenterList changes
  }, [getAllAuctionCenterList]);

  const columns = [
    {
      name: "index",
      title: "Sr.",
    },
    {
      name: "auctionCenterName",
      title: "Auction Center Name",
    },
    {
      name: "auctionCenterCode",
      title: "Auction Center Code",
    },
    {
      name: "certificateNo",
      title: "Registration Certificate Number",
    },
    {
      name: "isActive",
      title: "Status",
      getCellValue: (rows) => <StatusData data={rows} />,
    },
    {
      name: "action",
      title: "Action",
      getCellValue: (rows) => <ActionData data={rows} />,
    },
  ];
  function StatusData(data) {
    return (
      <>
        <div class="Switch">
          <div class="custom-control custom-switch">
            <input
              type="checkbox"
              class="custom-control-input"
              id="customSwitch1"
              checked={data.data.isActive === 1 ? true : false}
            />

            <label class="custom-control-label" for="customSwitch1">
              {data.data.isActive === 1 ? "Active" : "In-Active"}
            </label>
          </div>
        </div>
      </>
    );
  }
  function ActionData(data) {
    return (
      <>
        <div class="ActionBtn">
          <i
            className="fa fa-edit"
            onClick={() => handleEditClick(data.data.auctionCenterId)}
          ></i>
          <i
            className="fa fa-eye"
            onClick={() => {
              setShowmodal(true);
            }}
          ></i>
        </div>
      </>
    );
  }

  const removeFile = (index) => {
    setUploadedFiles((prevFiles) => {
      const newFiles = [...prevFiles];
      newFiles.splice(index, 1);
      return newFiles;
    });
  };

  const removeAllFiles = () => {
    setUploadedFiles([]);
  };
  const handleFileUpload = (event) => {
    const files = Array.from(event.target.files);
    setUploadedFiles(files);
  };

  const renderFileTypeIcon = (file) => {
    const extension = file.name.split(".").pop().toLowerCase();

    if (extension === "pdf") {
      return <AiOutlineFilePdf />;
    } else if (
      extension === "jpg" ||
      extension === "jpeg" ||
      extension === "png"
    ) {
      return <AiOutlineFileImage />;
    } else if (extension === "txt") {
      return <AiOutlineFileText />;
    } else {
      return <AiOutlineFile />;
    }
  };

  return (
    <>
      <Modals
        title={"Auction Center Master"}
        // show={open === "createAuctionCenter" ? true : false}
        show={
          open === "createAuctionCenter" || open === "editingAuctionCenterData"
        }
        handleClose={() => {
          setOpen("");
          setAuctionCenterName("");
          setAuctionCenterCode("");
          setCertificateNo("");
          setEditingAuctionCenterData(null);
        }}
        size="xl"
      >
        <Accordion
          expanded={expanded === "panel1"}
          className={`${expanded === "panel1" ? "active" : ""}`}
          onChange={handleChange("panel1")}
          TransitionProps={{ unmountOnExit: true }}
        >
          <AccordionSummary
            expandIcon={<ExpandMoreIcon />}
            aria-controls="panel1a-content"
            id="panel1a-header"
          >
            <Typography>
              {editingAuctionCenterData
                ? "Edit Auction Center"
                : " Create Auction Center"}
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              <div className="row">
                <div className="col-lg-12">
                  <div className="row align-items-end">
                    <div className="col-md-4">
                      <div className="FormGroup">
                        <label>Auction Center Name</label>
                        <input
                          type="text"
                          className="form-control"
                          // value={auctionCenterName}
                          // onChange={(e) => setAuctionCenterName(e.target.value)}
                          value={
                            editingAuctionCenterData?.auctionCenterName ||
                            auctionCenterName
                          }
                          onChange={(e) =>
                            editingAuctionCenterData
                              ? setEditingAuctionCenterData({
                                  ...editingAuctionCenterData,
                                  auctionCenterName: e.target.value,
                                })
                              : setAuctionCenterName(e.target.value)
                          }
                        />
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="FormGroup">
                        <label>Auction Center Code</label>
                        <input
                          type="text"
                          className="form-control"
                          // value={auctionCenterCode}
                          // onChange={(e) => setAuctionCenterCode(e.target.value)}
                          value={
                            editingAuctionCenterData?.auctionCenterCode ||
                            auctionCenterCode
                          }
                          onChange={(e) =>
                            editingAuctionCenterData
                              ? setEditingAuctionCenterData({
                                  ...editingAuctionCenterData,
                                  auctionCenterCode: e.target.value,
                                })
                              : setAuctionCenterCode(e.target.value)
                          }
                        />
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="FormGroup">
                        <label>Auction Center Certificate Number</label>
                        <input
                          type="text"
                          className="form-control"
                          // value={certificateNo}
                          // onChange={(e) => setCertificateNo(e.target.value)}
                          value={
                            editingAuctionCenterData?.certificateNo ||
                            certificateNo
                          }
                          onChange={(e) =>
                            editingAuctionCenterData
                              ? setEditingAuctionCenterData({
                                  ...editingAuctionCenterData,
                                  certificateNo: e.target.value,
                                })
                              : setCertificateNo(e.target.value)
                          }
                        />
                      </div>
                    </div>
                    <div className="col-md-12">
                      <div className="FormGroup">
                        <Card className="mt-3 FileUploadBox">
                          <Card.Body>
                            <Card.Title>File Upload</Card.Title>
                            <div className="FileUpload">
                              <input
                                type="file"
                                multiple
                                onChange={handleFileUpload}
                              />
                              <button onClick={() => removeAllFiles()}>
                                Remove All
                              </button>
                            </div>
                            {/* Render file type icons based on uploaded files */}
                            {uploadedFiles.map((file, index) => (
                              <div className="UploadedFile" key={index}>
                                <div>
                                  {renderFileTypeIcon(file)}
                                  <span>{file.name}</span>
                                </div>
                                <i
                                  className="fa fa-times"
                                  onClick={() => removeFile(index)}
                                ></i>
                              </div>
                            ))}
                          </Card.Body>
                        </Card>
                      </div>
                    </div>
                    <div className="col-md-12 mt-2">
                      <textarea
                        className="form-control"
                        placeholder="Enter Remarks"
                      ></textarea>
                    </div>
                    <div className="col-md-12">
                      <div className="BtnGroup">
                        <button className="SubmitBtn" onClick={handleSubmit}>
                          {editingAuctionCenterData ? "Update" : "Submit"}
                        </button>
                        <button
                          className="Clear"
                          onClick={() => {
                            //clear functionality to reset form fields
                            setAuctionCenterName("");
                            setAuctionCenterCode("");
                            setCertificateNo("");
                            setEditingAuctionCenterData(null);
                          }}
                        >
                          Clear
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </Typography>
          </AccordionDetails>
        </Accordion>
        <Accordion
          expanded={expanded === "panel2"}
          className={`${expanded === "panel2" ? "active" : ""}`}
          onChange={handleChange("panel2")}
        >
          <AccordionSummary
            expandIcon={<ExpandMoreIcon />}
            aria-controls="panel2a-content"
            id="panel2a-header"
          >
            <Typography>Manage Auction Center</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              <div className="row">
                <div className="col-lg-12">
                  <div className="row align-items-end">
                    <div className="col-md-4">
                      <div className="FormGroup">
                        <label>Auction Center Name</label>
                        <input type="text" className="form-control" />
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="FormGroup">
                        <label>Auction Center Code</label>
                        <select className="form-control select-form">
                          <option>1212</option>
                        </select>
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="FormGroup">
                        <label>Auction Center Certificate Number</label>
                        <input type="text" className="form-control" />
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="FormGroup">
                        <label>Status</label>
                        <select className="form-control select-form">
                          <option>All</option>
                          <option>Active</option>
                          <option>Inactive</option>
                        </select>
                      </div>
                    </div>
                    <div className="col-md-12">
                      <div className="BtnGroup">
                        <button className="SubmitBtn">Search</button>
                        <button className="Clear">Clear</button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="row">
                <div className="col-lg-12 mt-4">
                  <div className="TableBox CreateStateMaster">
                    <TableComponent
                      columns={columns}
                      // setColumns={setColumns}
                      rows={getAllAuctionCenterList?.map((row, index) => ({
                        ...row,
                        index: index + 1,
                      }))}
                      // rows={rows}
                      setRows={setRows}
                      sorting={true}
                      dragdrop={false}
                      fixedColumnsOn={false}
                      resizeingCol={false}
                    />
                  </div>
                </div>
              </div>
            </Typography>
          </AccordionDetails>
        </Accordion>
        <Accordion
          expanded={expanded === "panel3"}
          className={`${expanded === "panel3" ? "active" : ""}`}
          onChange={handleChange("panel3")}
          TransitionProps={{ unmountOnExit: true }}
        >
          <AccordionSummary
            expandIcon={<ExpandMoreIcon />}
            aria-controls="panel1a-content"
            id="panel1a-header"
          >
            <Typography>Uploaded Document</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              <TableComponent
                columns={columns}
                // setColumns={setColumns}
                rows={rows}
                setRows={setRows}
                sorting={true}
                dragdrop={false}
                fixedColumnsOn={false}
                resizeingCol={false}
              />
            </Typography>
          </AccordionDetails>
        </Accordion>
      </Modals>

      {showmodal && (
        <Modal show={showmodal} onHide={handleCloseHistory} size="lg" centered>
          <Modal.Header>
            <Modal.Title>History</Modal.Title>
            <i
              className="fa fa-times CloseModal"
              onClick={handleCloseHistory}
            ></i>
          </Modal.Header>
          <Modal.Body>
            <TableComponent
              columns={columns}
              // setColumns={setColumns}
              rows={rows}
              setRows={setRows}
              sorting={true}
              dragdrop={false}
              fixedColumnsOn={false}
              resizeingCol={false}
            />
          </Modal.Body>
        </Modal>
      )}
    </>
  );
}

export default CreateAuctionCenter;
