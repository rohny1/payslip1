import React, { useEffect, useState } from "react";
import {
  Card,
  FormControl,
  FormLabel,
  FormGroup,
  Button,
  Table,
  Col,
  Row,
} from "react-bootstrap";
import {
  AiOutlineFilePdf,
  AiOutlineFileImage,
  AiOutlineFileText,
  AiOutlineFile,
} from "react-icons/ai";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import {
  checkSaleNoExistence,
  createSaleProgramRequest,
  fetchPromptDatesByAuctionCenterRequest,
  teaTypeAction,
} from "../../../../store/actions/index";
import { useSelector } from "react-redux";
import { useDispatch } from "react-redux";
import NoData from "../../../../components/nodata/NoData";
import { SettingsSystemDaydreamSharp } from "@mui/icons-material";
import axios from "axios";

const AuctionCard = ({
  selectedSaleProgram,
  formData,
  generateYearOptions,
  handleYearChange,
  saleNumber,
  setSelectedSaleProgram,
  isDisabled,
  isEdit,
}) => {
  const dispatch = useDispatch();
  const auctionCenter = useSelector(
    (state) => state.auction.auctionCenter.responseData
  );
  const saleProgramList = useSelector(
    (state) => state.sale.saleProgramList.responseData
  );
  const [teaTypeList, setTeaTeatypeList] = useState([]);

  // const auctionId = auctionCenter.map((i) => i.auctionCenterId);
  // console.log(auctionId, "auction id");

  const [saleDate, setSaleDates] = useState("");
  const saleProgramDetail = useSelector((state) => state);
  const [saleProgramDetailList, setSaleProgramDetailList] = useState([]);
  const [selectedSalePrograms, setSelectedSalePrograms] = useState([]);
  const [salePromtDate, setSalePromtDate] = useState([]);

  const exists = useSelector((state) => state.auction.saleNumber);
  const currentDate = new Date().toISOString().split("T")[0];
  const [closingDate, setClosingDate] = useState(currentDate);
  const [publishingDate, setPublishingDate] = useState(currentDate);
  const [saleDates, setSaleDate] = useState(currentDate);
  const [selectedSaleNo, setSelectedSaleNo] = useState(1);
  const [numRows, setNumRows] = useState(1); // State to track the number of rows
  const auctionDays = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]; // Array of auction days
  const [uploadedFiles, setUploadedFiles] = useState([]);
  const [year, setYears] = useState(currentDate.split("-")[0]);
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize] = useState(10);
  const rows = []; // Replace with your actual array of rows
  const teaType = useSelector(
    (state) => state.teaType.teaTypeList.responseData
  );

  const saleDateData = useSelector(
    (state) => state?.auction?.promptDates?.responseData
  );

  useEffect(() => {
    setSalePromtDate(saleDateData?.at(0));
  }, [saleDateData]);

  console.log(salePromtDate, selectedSalePrograms, "qwe");
  useEffect(() => {
    dispatch(teaTypeAction());
  }, []);

  useEffect(() => {
    setTeaTeatypeList(teaType);
  }, [teaType]);

  // Get the total number of pages based on the number of items and the page size
  const totalPages = Math.ceil(numRows / pageSize);

  // Generate an array of page numbers
  const pageNumbers = Array.from(
    { length: totalPages },
    (_, index) => index + 1
  );

  // Get the items to display on the current page
  const startIndex = (currentPage - 1) * pageSize;
  const endIndex = Math.min(startIndex + pageSize, numRows);
  const itemsOnPage = Array.from(
    { length: numRows },
    (_, index) => index + startIndex
  );

  // Handle page change
  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  console.log(
    saleProgramDetailList
      ?.map((ele) => ele?.auctionDetails?.map((elee) => elee))[0]
      ?.map((ele) => ele),
    "😂😊"
  );

  useEffect(() => {
    setSaleProgramDetailList(
      saleProgramDetail.sale.saleProgramDetails.responseData
    );
  }, [saleProgramDetail]);

  const resateForm = () => {
    setYears("2023");
    setNumRows(1);
    setSelectedSaleNo(1);
    setSaleDate(currentDate);
    setPublishingDate(currentDate);
    setClosingDate(currentDate);
    setUploadedFiles([]);
    isDisabled = false;
    setNumRows(1);
    setSelectedSalePrograms([]);
  };

  // useEffect(()=>{
  //   setClosingDate(saleProgramDetailList[0].catalogPublishingDate)
  //   setPublishingDate(saleProgramDetailList[0].catalogPublishingDate)
  // },[saleProgramDetailList])

  const handleFileUpload = (event) => {
    const files = Array.from(event.target.files);
    setUploadedFiles(files);
  };
  console.log(exists);
  const handleSubmit = (e) => {
    e.preventDefault();
    // if (!closingDate || !publishingDate || !saleDates) {
    //   toast.error('Please fill in all the form fields');
    //   return;
    // }

    //

    // Dispatch the action with the payload
    //
    const currentDate = new Date().toISOString().split("T")[0];

    if (closingDate < currentDate) {
      toast.error("Closing date cannot be less than the current date");
      return;
    }

    if (publishingDate < currentDate) {
      toast.error("Publishing date cannot be less than the current date");
      return;
    }

    if (publishingDate <= closingDate) {
      toast.error(
        "Publishing date cannot be less than or equal to the closing date"
      );
      return;
    }
    if (!selectedSaleNo) {
      toast.error("Please select a sale number");
      return;
    }

    if (!closingDate) {
      toast.error("Please enter the closing date");
      return;
    }

    if (!publishingDate) {
      toast.error("Please enter the publishing date");
      return;
    }

    if (
      saleProgramList
        ?.map((ele) => ele.saleNo == selectedSaleNo)
        .includes(true) == true
    ) {
      toast.error("This sale no is already exist");
      return;
    }
    if (
      !selectedSalePrograms.every(
        (program) =>
          program.teaTypeId &&
          program.saleDate &&
          program.buyersPromptDate &&
          program.sellersPromptDate
      )
    ) {
      toast.error("Please fill in all auction days details");
      return;
    }
    if (!selectedSaleNo) {
      toast.error("Please select a sale number");
      return;
    }

    // if (saleNoExists.includes(true)) {
    //   toast.error("This sale number already exists");
    // } else {
    //   // dispatch(createSaleProgram(selectedSaleNo));
    //   dispatch(checkSaleNoExistence(parseInt(selectedSaleNo), year));
    //   toast.success("You can create a sale program");
    // }

    // console.log(

    // );
    setSelectedSalePrograms([
      ...selectedSalePrograms.filter((item) =>
        item?.teaTypeId === ""
          ? (item.teaTypeId = teaTypeList[0]?.teaTypeName)
          : item.teaTypeId
      ),
    ]);

    const data = {
      season: year,
      numRows: numRows,
      selectedSaleNo: selectedSaleNo,
      saleDates: saleDates,
      publishingDate: publishingDate,
      closingDate: closingDate,
      uploadedFiles: uploadedFiles,
      noOfAuctionDays: numRows,
      auctionDays: selectedSalePrograms,
    };
    console.log(data,"up")

    // const fomatdata = selectedSalePrograms.map((item) => {
    //   return {
    //     season: year,
    //     numRows: numRows,
    //     selectedSaleNo: selectedSaleNo,
    //     saleDates: saleDates,
    //     publishingDate: publishingDate,
    //     closingDate: closingDate,
    //     uploadedFiles: uploadedFiles,
    //     noOfAuctionDays: numRows,
    //     auctionDays: [
    //       {
    //         teaTypeId: item.teaTypeId,
    //         saleDate: item.saleDate,
    //         sellersPromptDate: item.sellersPromptDate,
    //         buyersPromptDate: item.buyersPromptDate,
    //       },
    //     ],
    //   };
    // });

    // Submit the form or perform any other necessary actions
    dispatch(createSaleProgramRequest(data));
    resateForm();
  };

  console.log(selectedSaleNo, "selectedSaleNo 🤣😊😂😘");
  const handleAuctionDaysChange = (e) => {
    const selectedValue = parseInt(e.target.value);

    if (selectedValue > numRows.length) {
      console.log(selectedValue);
    }

    setNumRows(selectedValue);
  };
  if (exists === true) {
    toast.success("You can create a sale program");
  } else if (exists === false) {
    toast.error("You are not allowed to create a sale program");
  }

  const renderFileTypeIcon = (file) => {
    const extension = file.name.split(".").pop().toLowerCase();

    if (extension === "pdf") {
      return <AiOutlineFilePdf />;
    } else if (
      extension === "jpg" ||
      extension === "jpeg" ||
      extension === "png"
    ) {
      return <AiOutlineFileImage />;
    } else if (extension === "txt") {
      return <AiOutlineFileText />;
    } else {
      return <AiOutlineFile />;
    }
  };

  const removeFile = (index) => {
    setUploadedFiles((prevFiles) => {
      const newFiles = [...prevFiles];
      newFiles.splice(index, 1);
      return newFiles;
    });
  };

  const removeAllFiles = () => {
    setUploadedFiles([]);
  };
  const handleSaleNoChange = (event) => {
    const selectedValue = event.target.value;

    // // if(exists)
    // console.log(,"😘😘😘");

    if (
      saleProgramList
        ?.map((ele) => ele.saleNo == selectedValue)
        .includes(true) == true
    ) {
      toast.error("This sale no is already exist");
    } else {
      toast.success("You can create a sale program");
    }
    setSelectedSaleNo(selectedValue);

    // Pass the selectedValue to the backend or perform any desired action
    // Example: dispatch an action to update the backend with the selected value
    // dispatch(updateSaleNoRequest(selectedValue));
  };

  if (!exists || !saleProgramDetail) {
    return (
      <div>
        <NoData />
      </div>
    ); // Show a message when no data is available
  }
  const handleSaleDateChange = (e) => {
    const selectedSaleDate = e.target.value;
    setSaleDates(selectedSaleDate);
  };
  // Function to update the state for a specific row/item

  const updateSelectedSaleProgram = (index, updatedProgram) => {
    try {
      const updatedPrograms = [...selectedSalePrograms];
      updatedPrograms[index] = updatedProgram;

      if (updatedProgram.saleDate) {
        // Make the API call using Axios POST method
        const apiUrl =
          "http://192.168.101.75:5080/api/SaleProgram/GetPromptDateByAuctionCenter";
        const requestData = {
          auctionCenterId: 1,
          saleDate: updatedPrograms[index].saleDate,
        };

        axios.post(apiUrl, requestData).then((response) => {
          const { buyersPromptDate, sellersPromptDate } =
            response.data.responseData[0];

          // Create a new object with the combined data
          const combinedObject = {
            ...updatedPrograms[index],
            sellersPromptDate,
            buyersPromptDate,
          };

          // Replace the element in the updatedPrograms array with the combined object
          updatedPrograms[index] = combinedObject;
          setSelectedSalePrograms(updatedPrograms);
        });

        // Assuming the API response data is a single object with keys "saleDate" and "buyersPromptDate"
      }
    } catch (error) {
      console.error("API call error:", error);
      // Handle the error if needed
    }
  };
  return (
    <>
      <Row>
        <Col xs={12} md={5}>
          <Card>
            <form onSubmit={handleSubmit} className="p-2">
              <FormGroup className="w-100 mt-2">
                <FormLabel>Season</FormLabel>
                <FormControl
                  as="select"
                  name="age1"
                  value={
                    selectedSaleNo !== null
                      ? selectedSaleNo
                      : saleNumber[0].saleNo
                  }
                  onChange={(e) => setYears(e.target.value)}
                  disabled={isDisabled}
                >
                  {generateYearOptions()}
                </FormControl>
              </FormGroup>

              <FormGroup className="w-100 mt-2">
                <FormLabel>Sale No</FormLabel>
                <FormControl
                  as="select"
                  value={
                    saleProgramDetailList?.map((ele) => ele.saleNo) ||
                    selectedSaleNo ||
                    saleNumber[0].saleNo
                  }
                  onChange={handleSaleNoChange}
                  size="sm"
                  disabled={isDisabled}
                >
                  {saleNumber.map((e) => (
                    <option key={e.saleNo} value={e.saleNo}>
                      {e.saleNo}
                    </option>
                  ))}
                </FormControl>
              </FormGroup>

              <FormGroup className="w-100 mt-2">
                <FormLabel>Catalog Closing Date</FormLabel>
                <FormControl
                  as="input"
                  type="date"
                  size="sm"
                  // value={closingDate}
                  value={
                    saleProgramDetailList?.map(
                      (ele) => ele.catalogClosingDate.split("T")[0]
                    ) || closingDate
                  }
                  disabled={isDisabled}
                  onChange={(e) => setClosingDate(e.target.value)}
                />
              </FormGroup>

              <FormGroup className="mt-2" fullWidth>
                <FormLabel>Catalog Publish Date</FormLabel>
                <FormControl
                  as="input"
                  type="date"
                  size="sm"
                  // value={publishingDate}
                  value={
                    saleProgramDetailList?.map(
                      (ele) => ele.catalogPublishingDate.split("T")[0]
                    ) || publishingDate
                  }
                  disabled={isDisabled}
                  onChange={(e) => setPublishingDate(e.target.value)}
                />
              </FormGroup>

              <FormGroup className="w-100 mt-3">
                <FormLabel>No. of Auction Days</FormLabel>
                <FormControl
                  as="select"
                  value={
                    saleProgramDetailList?.map((ele) => ele.noOfAuctionDays) ||
                    numRows ||
                    auctionDays[0]
                  }
                  disabled={isDisabled}
                  onChange={handleAuctionDaysChange}
                  size="sm"
                >
                  {auctionDays.map((day) => (
                    <option key={day} value={day}>
                      {day}
                    </option>
                  ))}
                </FormControl>
              </FormGroup>

              {isDisabled !== true && (
                <>
                  <Button className="mt-2 SubmitBtn" type="submit">
                    Submit
                  </Button>
                  <Button className="mt-2 SubmitBtn ml-2" onClick={resateForm}>
                    Resate
                  </Button>
                </>
              )}
            </form>
          </Card>
        </Col>
        <Col xs={12} md={7}>
          <Card>
            {isDisabled === true || isEdit === true ? (
              <>
                <Table>
                  <thead>
                    <tr>
                      <th>Tea Type</th>
                      <th>Sale Date</th>
                      <th>Buyer's Prompt Date</th>
                      <th>Seller's Prompt Date</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {saleProgramDetailList
                      ?.map((ele) =>
                        ele?.auctionDetails?.map((elee) => elee)
                      )[0]
                      ?.map((item, index) => (
                        <tr key={index}>
                          <td>
                            <FormControl
                              as="select"
                              disabled={isDisabled}
                              size="sm"
                              value={
                                selectedSalePrograms[index]?.teaTypeId ||
                                item?.teaTypeId
                              }
                              onChange={(e) => {
                                const updatedProgram = {
                                  ...selectedSalePrograms[index],
                                  teaTypeId: e.target.value,
                                };
                                updateSelectedSaleProgram(
                                  index,
                                  updatedProgram
                                );
                              }}
                            >
                              {teaTypeList?.length > 0
                                ? teaTypeList?.map((item, index) => (
                                    <option value={item?.teaTypeId}>
                                      {item.teaTypeName}
                                    </option>
                                  ))
                                : "No Data"}
                            </FormControl>
                          </td>
                          <td>
                            <input
                              type="date"
                              id="saleDate"
                              value={
                                selectedSalePrograms[index]?.saleDate ||
                                item?.saleDate?.split("T")[0]
                              }
                              disabled={isDisabled}
                              onChange={(e) => {
                                const updatedProgram = {
                                  ...selectedSalePrograms[index],
                                  saleDate: e.target.value,
                                };
                                updateSelectedSaleProgram(
                                  index,
                                  updatedProgram
                                );
                              }}
                            />
                          </td>
                          <td>
                            <input
                              type="date"
                              disabled={true}
                              value={
                                selectedSalePrograms[
                                  index
                                ]?.buyersPromptDate?.split("T")[0] ||
                                item?.buyersPromptDate?.split("T")[0]
                              }
                            />
                          </td>
                          <td>
                            <input
                              disabled={true}
                              type="date"
                              value={
                                selectedSalePrograms[
                                  index
                                ]?.sellersPromptDate?.split("T")[0] ||
                                item?.sellersPromptDate?.split("T")[0]
                                // selectedSalePrograms[index]?.sellersPromptDate?
                              }
                            />
                          </td>
                          <td>{item.status}</td>
                        </tr>
                      ))}
                  </tbody>
                </Table>
              </>
            ) : (
              <>
                <Table>
                  <thead>
                    <tr>
                      <th>Tea Type</th>
                      <th>Sale Date</th>
                      <th>Buyer's Prompt Date</th>
                      <th>Seller's Prompt Date</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {itemsOnPage
                      .slice(startIndex, endIndex)
                      .map((item, index) => (
                        <tr key={index}>
                          <td>
                            <FormControl
                              as="select"
                              disabled={isDisabled}
                              size="sm"
                              value={
                                selectedSalePrograms[index]?.teaTypeId || ""
                              }
                              onChange={(e) => {
                                const updatedProgram = {
                                  ...selectedSalePrograms[index],
                                  teaTypeId: e.target.value,
                                };
                                updateSelectedSaleProgram(
                                  index,
                                  updatedProgram
                                );
                              }}
                            >
                              {teaTypeList?.length > 0
                                ? teaTypeList?.map((item, index) => (
                                    <option value={item?.teaTypeId}>
                                      {item.teaTypeName}
                                    </option>
                                  ))
                                : "No Data"}
                            </FormControl>
                          </td>
                          <td>
                            <input
                              type="date"
                              id="saleDate"
                              value={
                                selectedSalePrograms[index]?.saleDate || ""
                              }
                              disabled={isDisabled}
                              onChange={(e) => {
                                const updatedProgram = {
                                  ...selectedSalePrograms[index],
                                  saleDate: e.target.value,
                                };
                                updateSelectedSaleProgram(
                                  index,
                                  updatedProgram
                                );
                              }}
                            />
                          </td>
                          <td>
                            <input
                              type="date"
                              disabled={true}
                              value={
                                selectedSalePrograms[
                                  index
                                ]?.buyersPromptDate?.split("T")[0] || ""
                              }
                            />
                          </td>
                          <td>
                            <input
                              disabled={true}
                              type="date"
                              value={
                                selectedSalePrograms[
                                  index
                                ]?.sellersPromptDate?.split("T")[0] || ""
                                // selectedSalePrograms[index]?.sellersPromptDate?
                              }
                            />
                          </td>
                          <td>
                            {selectedSaleProgram?.status === null
                              ? "-"
                              : selectedSaleProgram?.status}
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </Table>
              </>
            )}

            <div>
              <ul className="pagination">
                {/* Previous page button */}
                <li
                  className={`page-item ${currentPage === 1 ? "disabled" : ""}`}
                >
                  <button
                    className="page-link"
                    onClick={() => handlePageChange(currentPage - 1)}
                  >
                    Previous
                  </button>
                </li>

                {/* Page buttons */}
                {pageNumbers.map((page) => (
                  <li
                    key={page}
                    className={`page-item ${
                      currentPage === page ? "active" : ""
                    }`}
                  >
                    <button
                      className="page-link"
                      onClick={() => handlePageChange(page)}
                    >
                      {page}
                    </button>
                  </li>
                ))}

                {/* Next page button */}
                <li
                  className={`page-item ${
                    currentPage === totalPages ? "disabled" : ""
                  }`}
                >
                  <button
                    className="page-link"
                    onClick={() => handlePageChange(currentPage + 1)}
                  >
                    Next
                  </button>
                </li>
              </ul>
            </div>
          </Card>
        </Col>
      </Row>
      <Card className="mt-3 FileUploadBox">
        <Card.Body>
          <Card.Title>File Upload</Card.Title>
          <div className="FileUpload">
            <input type="file" multiple onChange={handleFileUpload} />
            <button onClick={() => removeAllFiles()}>Remove All</button>
          </div>
          {/* Render file type icons based on uploaded files */}
          {uploadedFiles.map((file, index) => (
            <div className="UploadedFile" key={index}>
              <div>
                {renderFileTypeIcon(file)}
                <span>{file.name}</span>
              </div>
              <i className="fa fa-times" onClick={() => removeFile(index)}></i>
            </div>
          ))}
        </Card.Body>
      </Card>
      <ToastContainer />
    </>
  );
};

export default AuctionCard;
