import React from 'react'

const DummyModal = () => {
  return (
    <div>DummyModal</div>
  )
}

export default DummyModal