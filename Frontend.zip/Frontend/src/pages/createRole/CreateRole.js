import React, { useState, useEffect } from "react";
import Modals from "../../components/common/Modal";
import TableComponent from "../../components/tableComponent/TableComponent";
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Typography,
} from "@mui/material";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import { Card, Modal } from "react-bootstrap";
import {
  AiOutlineFile,
  AiOutlineFileImage,
  AiOutlineFilePdf,
  AiOutlineFileText,
} from "react-icons/ai";
import {
  getAllRoles,
  createRole,
  updateRole,
  getRoleById,
} from "../../store/actions";
import { useSelector } from "react-redux";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";

function CreateRole({ open, setOpen }) {
  const getAllRoleData = useSelector(
    (state) => state.role.allRoles.responseData
  );

  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [roleName, setRoleName] = useState("");
  const [editingRoleData, setEditingRoleData] = useState(null);

  const handleSubmit = (e) => {
    e.preventDefault();
    const roleData = {
      roleName: roleName,
      isActive: 1,
      userId: 1,
    };
    try {
      if (editingRoleData) {
        editingRoleData.userId = 1;
        dispatch(updateRole(editingRoleData));
        // console.log("Updated state", editingRoleData);
      } else {
        dispatch(createRole(roleData));
      }

      setRoleName("");
      setEditingRoleData(null);
      setExpanded("panel2");
    } catch (e) {}
  };
  // Function to handle edit button click
  const handleEditClick = (roleId) => {
    dispatch(getRoleById(roleId));
    setExpanded("panel1");
  };
  const editingRoleDataFromId = useSelector(
    (state) => state.role.roleById.responseData
    // .state.stateData.responseData
  );
  // console.log("edited-data:", editingRoleDataFromId);
  useEffect(() => {
    if (editingRoleDataFromId) {
      setEditingRoleData(editingRoleDataFromId);
    } else {
      setEditingRoleData(null);
      dispatch(getAllRoles()); // Dispatch the action to fetch auction center data
    }
  }, [editingRoleDataFromId]);

  const [expanded, setExpanded] = React.useState("panel1");
  const [showmodal, setShowmodal] = useState(false);
  const handleCloseHistory = () => setShowmodal(false);
  const [uploadedFiles, setUploadedFiles] = useState([]);
  const handleChange = (panel) => (event, isExpanded) => {
    setExpanded(isExpanded ? panel : false);
  };

  const [rows, setRows] = useState(getAllRoleData);
  useEffect(() => {
    setRows(getAllRoleData); // Update rows when getAllState changes
  }, [getAllRoleData]);
  const columns = [
    {
      name: "index",
      title: "Sr.",
    },
    {
      name: "roleName",
      title: "Role Name",
    },
    {
      name: "isActive",
      title: "Status",
      getCellValue: (rows) => <StatusData data={rows} />,
    },
    {
      name: "action",
      title: "Action",
      getCellValue: (rows) => <ActionData data={rows} />,
    },
  ];
  function StatusData(data) {
    return (
      <>
        <div class="Switch">
          <div class="custom-control custom-switch">
            <input
              type="checkbox"
              class="custom-control-input"
              id="customSwitch1"
              checked={data.data.isActive === 1 ? true : false}
            />

            <label class="custom-control-label" for="customSwitch1">
              {data.data.isActive === 1 ? "Active" : "In-Active"}
            </label>
          </div>
        </div>
      </>
    );
  }
  function ActionData(data) {
    return (
      <>
        <div class="ActionBtn">
          <i
            className="fa fa-edit"
            onClick={() => handleEditClick(data.data.roleId)}
          ></i>
          <i
            className="fa fa-eye"
            onClick={() => {
              setShowmodal(true);
            }}
          ></i>
        </div>
      </>
    );
  }

  const removeFile = (index) => {
    setUploadedFiles((prevFiles) => {
      const newFiles = [...prevFiles];
      newFiles.splice(index, 1);
      return newFiles;
    });
  };

  const removeAllFiles = () => {
    setUploadedFiles([]);
  };
  const handleFileUpload = (event) => {
    const files = Array.from(event.target.files);
    setUploadedFiles(files);
  };

  const renderFileTypeIcon = (file) => {
    const extension = file.name.split(".").pop().toLowerCase();

    if (extension === "pdf") {
      return <AiOutlineFilePdf />;
    } else if (
      extension === "jpg" ||
      extension === "jpeg" ||
      extension === "png"
    ) {
      return <AiOutlineFileImage />;
    } else if (extension === "txt") {
      return <AiOutlineFileText />;
    } else {
      return <AiOutlineFile />;
    }
  };

  return (
    <>
      <Modals
        title={"Role Master"}
        show={open === "createRole" || open === "editingRoleData"}
        handleClose={() => {
          setOpen("");
          setRoleName("");
          setEditingRoleData(null);
        }}
        size="xl"
      >
        <Accordion
          expanded={expanded === "panel1"}
          className={`${expanded === "panel1" ? "active" : ""}`}
          onChange={handleChange("panel1")}
          TransitionProps={{ unmountOnExit: true }}
        >
          <AccordionSummary
            expandIcon={<ExpandMoreIcon />}
            aria-controls="panel1a-content"
            id="panel1a-header"
          >
            <Typography>
              {editingRoleData ? "Edit Role" : "Create Role"}
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              <div className="row">
                <div className="col-lg-12">
                  <div className="row align-items-end">
                    <div className="col-md-6">
                      <div className="FormGroup">
                        <label>Role Name</label>
                        <input
                          type="text"
                          className="form-control"
                          // value={roleName}
                          // onChange={(e) => setRoleName(e.target.value)}
                          value={editingRoleData?.roleName || roleName}
                          onChange={(e) =>
                            editingRoleData
                              ? setEditingRoleData({
                                  ...editingRoleData,
                                  roleName: e.target.value,
                                })
                              : setRoleName(e.target.value)
                          }
                        />
                      </div>
                    </div>

                    <div className="col-md-12">
                      <div className="FormGroup">
                        <Card className="mt-3 FileUploadBox">
                          <Card.Body>
                            <Card.Title>File Upload</Card.Title>
                            <div className="FileUpload">
                              <input
                                type="file"
                                multiple
                                onChange={handleFileUpload}
                              />
                              <button onClick={() => removeAllFiles()}>
                                Remove All
                              </button>
                            </div>
                            {/* Render file type icons based on uploaded files */}
                            {uploadedFiles.map((file, index) => (
                              <div className="UploadedFile" key={index}>
                                <div>
                                  {renderFileTypeIcon(file)}
                                  <span>{file.name}</span>
                                </div>
                                <i
                                  className="fa fa-times"
                                  onClick={() => removeFile(index)}
                                ></i>
                              </div>
                            ))}
                          </Card.Body>
                        </Card>
                      </div>
                    </div>
                    <div className="col-md-12 mt-2">
                      <textarea
                        className="form-control"
                        placeholder="Enter Remarks"
                      ></textarea>
                    </div>
                    <div className="col-md-12">
                      <div className="BtnGroup">
                        <button className="SubmitBtn" onClick={handleSubmit}>
                          {editingRoleData ? "Update" : "Submit"}
                        </button>
                        <button
                          className="Clear"
                          onClick={() => {
                            //clear functionality to reset form fields
                            setRoleName("");
                            setEditingRoleData(null);
                          }}
                        >
                          Clear
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </Typography>
          </AccordionDetails>
        </Accordion>
        <Accordion
          expanded={expanded === "panel2"}
          className={`${expanded === "panel2" ? "active" : ""}`}
          onChange={handleChange("panel2")}
        >
          <AccordionSummary
            expandIcon={<ExpandMoreIcon />}
            aria-controls="panel2a-content"
            id="panel2a-header"
          >
            <Typography>Manage Role</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              <div className="row">
                <div className="col-lg-12">
                  <div className="row align-items-end">
                    <div className="col-md-6">
                      <div className="FormGroup">
                        <label>Role Name</label>
                        <select className="form-control select-form">
                          <option>1212</option>
                        </select>
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="FormGroup">
                        <label>Status</label>
                        <select className="form-control select-form">
                          <option>All</option>
                          <option>Active</option>
                          <option>Inactive</option>
                        </select>
                      </div>
                    </div>
                    <div className="col-md-12">
                      <div className="BtnGroup">
                        <button className="SubmitBtn">Search</button>
                        <button className="Clear">Clear</button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="row">
                <div className="col-lg-12 mt-4">
                  <div className="TableBox CreateStateMaster">
                    <TableComponent
                      columns={columns}
                      // setColumns={setColumns}
                      rows={getAllRoleData?.map((row, index) => ({
                        ...row,
                        index: index + 1,
                      }))}
                      // rows={rows}
                      setRows={setRows}
                      sorting={true}
                      dragdrop={false}
                      fixedColumnsOn={false}
                      resizeingCol={false}
                    />
                  </div>
                </div>
              </div>
            </Typography>
          </AccordionDetails>
        </Accordion>
        <Accordion
          expanded={expanded === "panel3"}
          className={`${expanded === "panel3" ? "active" : ""}`}
          onChange={handleChange("panel3")}
          TransitionProps={{ unmountOnExit: true }}
        >
          <AccordionSummary
            expandIcon={<ExpandMoreIcon />}
            aria-controls="panel1a-content"
            id="panel1a-header"
          >
            <Typography>Uploaded Document</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              <TableComponent
                columns={columns}
                // setColumns={setColumns}
                rows={rows}
                setRows={setRows}
                sorting={true}
                dragdrop={false}
                fixedColumnsOn={false}
                resizeingCol={false}
              />
            </Typography>
          </AccordionDetails>
        </Accordion>
      </Modals>

      {showmodal && (
        <Modal show={showmodal} onHide={handleCloseHistory} size="lg" centered>
          <Modal.Header>
            <Modal.Title>History</Modal.Title>
            <i
              className="fa fa-times CloseModal"
              onClick={handleCloseHistory}
            ></i>
          </Modal.Header>
          <Modal.Body>
            <TableComponent
              columns={columns}
              // setColumns={setColumns}
              rows={rows}
              setRows={setRows}
              sorting={true}
              dragdrop={false}
              fixedColumnsOn={false}
              resizeingCol={false}
            />
          </Modal.Body>
        </Modal>
      )}
    </>
  );
}

export default CreateRole;
