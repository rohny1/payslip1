import React, { useState, useEffect } from "react";
import Modals from "../../components/common/Modal";
import TableComponent from "../../components/tableComponent/TableComponent";
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Typography,
} from "@mui/material";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import { Card, Form, Modal } from "react-bootstrap";
import {
  AiOutlineFile,
  AiOutlineFileImage,
  AiOutlineFilePdf,
  AiOutlineFileText,
} from "react-icons/ai";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import {
  getAllStateAction,
  createStateAction,
  getStateByIdAction,
  updateStateAction,
} from "../../store/actions/createStateMaster/stateActions";

function CreateStateMaster({ open, setOpen }) {
  const getAllState = useSelector(
    (state) => state.state.getAllState.responseData
  );

  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [stateName, setStateName] = useState("");
  const [stateCode, setStateCode] = useState("");
  const [stateInitial, setStateInitial] = useState("");
  const [editingStateData, setEditingStateData] = useState(null);

  const [submitSuccess, setSubmitSuccess] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const newStateData = {
      stateName: stateName,
      stateCode: stateCode,
      stateInitial: stateInitial,
      userId: 1,
      isActive: 1,
    };
    try {
      if (editingStateData) {
        dispatch(updateStateAction(editingStateData));
      } else {
        dispatch(createStateAction(newStateData));
      }

      setStateName("");
      setStateCode("");
      setStateInitial("");
      setEditingStateData(null); // Clear the editingStateData after successful submit
      setExpanded("panel2");
    } catch (error) {
      setSubmitSuccess(false);
    }
  };

  // Function to handle edit button click
  const handleEditClick = (stateId) => {
    dispatch(getStateByIdAction(stateId));
    setExpanded("panel1");
  };
  const editingStateDataFromState = useSelector(
    (state) => state.state.stateData.responseData
    // .state.stateData.responseData
  );

  //console.log("edited-data:", editingStateDataFromState);

  useEffect(() => {
    if (editingStateDataFromState) {
      setEditingStateData(editingStateDataFromState);
    } else {
      setEditingStateData(null);
      dispatch(getAllStateAction());
    }
    // if (!editingStateDataFromState) {
    //   dispatch(getAllStateAction());
    // }
  }, [editingStateDataFromState]);

  const [expanded, setExpanded] = React.useState("panel1");
  const [showmodal, setShowmodal] = useState(false);
  const handleCloseHistory = () => setShowmodal(false);
  const handleChange = (panel) => (event, isExpanded) => {
    setExpanded(isExpanded ? panel : false);
  };

  const [rows, setRows] = useState(getAllState);

  useEffect(() => {
    setRows(getAllState); // Update rows when getAllState changes
  }, [getAllState]);

  const columns = [
    {
      name: "stateName",
      title: "State",
    },
    {
      name: "stateCode",
      title: "State Code",
    },
    {
      name: "stateInitial",
      title: "State Initial",
    },
    {
      name: "isActive",
      title: "Status",
      getCellValue: (rows) => <StatusData data={rows} />,
    },
    {
      name: "action",
      title: "Action",
      getCellValue: (rows) => <ActionData data={rows} />,
    },
  ];

  function StatusData(data) {
    return (
      <>
        <div class="Switch">
          <div class="custom-control custom-switch">
            <input
              type="checkbox"
              class="custom-control-input"
              id="customSwitch1"
              checked={data.data.isActive === 1 ? true : false}
            />

            <label class="custom-control-label" for="customSwitch1">
              {data.data.isActive === 1 ? "Active" : "In-Active"}
            </label>
          </div>
        </div>
      </>
    );
  }

  const [uploadedFiles, setUploadedFiles] = useState([]);

  const handleFileUpload = (event) => {
    const files = Array.from(event.target.files);
    setUploadedFiles((prevFiles) => [...prevFiles, ...files]);
  };

  const renderFileTypeIcon = (file) => {
    const extension = file.name.split(".").pop().toLowerCase();

    if (extension === "pdf") {
      return <AiOutlineFilePdf />;
    } else if (
      extension === "jpg" ||
      extension === "jpeg" ||
      extension === "png"
    ) {
      return <AiOutlineFileImage />;
    } else if (extension === "txt") {
      return <AiOutlineFileText />;
    } else {
      return <AiOutlineFile />;
    }
  };

  const removeFile = (index) => {
    setUploadedFiles((prevFiles) => {
      const newFiles = [...prevFiles];
      newFiles.splice(index, 1);
      return newFiles;
    });
  };

  const removeAllFiles = () => {
    setUploadedFiles([]);
  };

  function ActionData(data) {
    return (
      <>
        <div class="ActionBtn">
          <i
            className="fa fa-edit"
            onClick={() => handleEditClick(data.data.stateID)}
          ></i>
          <i
            className="fa fa-eye"
            onClick={() => {
              setShowmodal(true);
            }}
          ></i>
        </div>
      </>
    );
  }

  return (
    <>
      <Modals
        title={"State Master"}
        handleClose={() => {
          setOpen("");
          setStateName("");
          setStateCode("");
          setStateInitial("");
          setEditingStateData(null);
        }}
        show={open === "createStateMaster" || open === "editingStateData"}
        size="xl"
      >
        <Accordion
          expanded={expanded === "panel1"}
          className={`${expanded === "panel1" ? "active" : ""}`}
          onChange={handleChange("panel1")}
          TransitionProps={{ unmountOnExit: true }}
        >
          <AccordionSummary
            expandIcon={<ExpandMoreIcon />}
            aria-controls="panel1a-content"
            id="panel1a-header"
          >
            <Typography>
              {editingStateData ? "Edit State" : "Create State"}
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              <div className="row">
                <div className="col-lg-12">
                  <div className="row">
                    <div className="col-md-12">
                      <div className="row align-items-end">
                        <div className="col-md-4">
                          <div className="FormGroup">
                            <label>State Name</label>
                            <input
                              type="text"
                              className="form-control"
                              required
                              value={editingStateData?.stateName || stateName}
                              onChange={(e) =>
                                editingStateData
                                  ? setEditingStateData({
                                      ...editingStateData,
                                      stateName: e.target.value,
                                    })
                                  : setStateName(e.target.value)
                              }
                            />
                          </div>
                        </div>
                        <div className="col-md-4">
                          <div className="FormGroup">
                            <label>State Code</label>
                            <input
                              type="text"
                              className="form-control"
                              required
                              value={editingStateData?.stateCode || stateCode}
                              onChange={(e) =>
                                editingStateData
                                  ? setEditingStateData({
                                      ...editingStateData,
                                      stateCode: e.target.value,
                                    })
                                  : setStateCode(e.target.value)
                              }
                            />
                          </div>
                        </div>
                        <div className="col-md-4">
                          <div className="FormGroup">
                            <label>State Initial</label>
                            <input
                              type="text"
                              className="form-control"
                              required
                              value={
                                editingStateData?.stateInitial || stateInitial
                              }
                              onChange={(e) =>
                                editingStateData
                                  ? setEditingStateData({
                                      ...editingStateData,
                                      stateInitial: e.target.value,
                                    })
                                  : setStateInitial(e.target.value)
                              }
                            />
                          </div>
                        </div>
                        <div className="col-md-12">
                          <div className="FormGroup">
                            <Card className="mt-3 FileUploadBox">
                              <Card.Body>
                                <Card.Title>File Upload</Card.Title>
                                <div className="FileUpload">
                                  <input
                                    type="file"
                                    multiple
                                    onChange={handleFileUpload}
                                  />
                                  <button onClick={() => removeAllFiles()}>
                                    Remove All
                                  </button>
                                </div>
                                {/* Render file type icons based on uploaded files */}
                                {uploadedFiles?.map((file, index) => (
                                  <div className="UploadedFile" key={index}>
                                    <div>
                                      {renderFileTypeIcon(file)}
                                      <span>{file.name}</span>
                                    </div>
                                    <i
                                      className="fa fa-times"
                                      onClick={() => removeFile(index)}
                                    ></i>
                                  </div>
                                ))}
                              </Card.Body>
                            </Card>
                          </div>
                        </div>
                        <div className="col-md-12 mt-2">
                          <textarea
                            className="form-control"
                            placeholder="Enter Remarks"
                          ></textarea>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-md-12">
                      <div className="BtnGroup">
                        <button className="SubmitBtn" onClick={handleSubmit}>
                          {editingStateData ? "Update" : "Submit"}
                        </button>
                        <button
                          className="Clear"
                          onClick={() => {
                            //clear functionality to reset form fields
                            setStateName("");
                            setStateCode("");
                            setStateInitial("");
                            setEditingStateData(null);
                          }}
                        >
                          Clear
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </Typography>
          </AccordionDetails>
        </Accordion>
        <Accordion
          expanded={expanded === "panel2"}
          className={`${expanded === "panel2" ? "active" : ""}`}
          onChange={handleChange("panel2")}
        >
          <AccordionSummary
            expandIcon={<ExpandMoreIcon />}
            aria-controls="panel2a-content"
            id="panel2a-header"
          >
            <Typography>Manage State Master</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              <div className="row">
                <div className="col-lg-12">
                  <div className="row align-items-end">
                    <div className="col-md-3">
                      <div className="FormGroup">
                        <label>State Name</label>
                        <input type="text" className="form-control" />
                      </div>
                    </div>
                    <div className="col-md-3">
                      <div className="FormGroup">
                        <label>State Code</label>
                        <select className="form-control select-form">
                          {getAllState?.map((data, index) => (
                            <option value={data.stateCode}>
                              {data.stateCode}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                    <div className="col-md-3">
                      <div className="FormGroup">
                        <label>State Initial</label>
                        <input type="text" className="form-control" />
                      </div>
                    </div>
                    <div className="col-md-3">
                      <div className="FormGroup">
                        <label>Status</label>
                        <select className="form-control select-form">
                          <option>All</option>
                          <option>Active</option>
                          <option>Inactive</option>
                        </select>
                      </div>
                    </div>
                    <div className="col-md-3">
                      <div className="BtnGroup">
                        <button className="SubmitBtn">Search</button>
                        <button className="Clear">Clear</button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="row">
                <div className="col-lg-12 mt-4">
                  <div className="TableBox CreateStateMaster">
                    <TableComponent
                      columns={columns}
                      // setColumns={setColumns}
                      rows={rows?.length > 0 ? rows : []}
                      setRows={setRows}
                      sorting={true}
                      dragdrop={false}
                      fixedColumnsOn={false}
                      resizeingCol={false}
                    />
                  </div>
                </div>
              </div>
            </Typography>
          </AccordionDetails>
        </Accordion>
        <Accordion
          expanded={expanded === "panel3"}
          className={`${expanded === "panel3" ? "active" : ""}`}
          onChange={handleChange("panel3")}
          TransitionProps={{ unmountOnExit: true }}
        >
          <AccordionSummary
            expandIcon={<ExpandMoreIcon />}
            aria-controls="panel1a-content"
            id="panel1a-header"
          >
            <Typography>Uploaded Document</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              <TableComponent
                columns={columns}
                // setColumns={setColumns}
                rows={rows}
                setRows={setRows}
                sorting={true}
                dragdrop={false}
                fixedColumnsOn={false}
                resizeingCol={false}
              />
            </Typography>
          </AccordionDetails>
        </Accordion>
      </Modals>

      {showmodal && (
        <Modal show={showmodal} onHide={handleCloseHistory} size="lg" centered>
          <Modal.Header>
            <Modal.Title>History</Modal.Title>
            <i
              className="fa fa-times CloseModal"
              onClick={handleCloseHistory}
            ></i>
          </Modal.Header>
          <Modal.Body>
            <TableComponent
              columns={columns}
              // setColumns={setColumns}
              rows={rows}
              setRows={setRows}
              sorting={true}
              dragdrop={false}
              fixedColumnsOn={false}
              resizeingCol={false}
            />
          </Modal.Body>
        </Modal>
      )}
    </>
  );
}

export default CreateStateMaster;
