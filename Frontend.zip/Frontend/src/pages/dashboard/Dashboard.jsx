import React, { useEffect } from 'react'
import CenterCard from '../../components/center-card/CenterCard'

const Dashboard = () => {
  
  return (
    <>
    <CenterCard/>
    </>
  )
}

export default Dashboard