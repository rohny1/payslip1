import React from 'react'

const FormPage = () => {
  return (
    <>FormPage</>
  )
}

export default FormPage