import React, { useState, useEffect } from "react";
import Modals from "../../components/common/Modal";
import TableComponent from "../../components/tableComponent/TableComponent";
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Typography,
} from "@mui/material";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import { Card, Modal } from "react-bootstrap";
import {
  AiOutlineFile,
  AiOutlineFileImage,
  AiOutlineFilePdf,
  AiOutlineFileText,
} from "react-icons/ai";
import {
  getAllTeaTypes,
  createTeaType,
  updateTeaType,
  getTeaTypeById,
} from "../../store/actions";
import { useSelector } from "react-redux";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";

function CreateTeaType({ open, setOpen }) {
  const getAllTeaType = useSelector(
    (state) => state.teaTypeManage.allTeaTypes.responseData
  );

  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [categoryName, setCategoryName] = useState("");
  const [categoryCode, setCategoryCode] = useState("");
  const [teaTypeName, setTeaTypeName] = useState("");
  const [editingTeaTypeData, setEditingTeatypeData] = useState(null);

  const handleSubmit = (e) => {
    e.preventDefault();
    const teaTypeData = {
      categoryName: categoryName,
      categoryCode: categoryCode,
      teaTypeName: teaTypeName,
      isActive: 1,
      userId: 1,
    };
    try {
      if (editingTeaTypeData) {
        editingTeaTypeData.userId = 1;
        dispatch(updateTeaType(editingTeaTypeData));
      } else {
        dispatch(createTeaType(teaTypeData));
      }
      setCategoryName("");
      setCategoryCode("");
      setTeaTypeName("");
      setEditingTeatypeData(null);
      setExpanded("panel2");
    } catch (e) {}
  };

  // Function to handle edit button click
  const handleEditClick = (teaTypeId) => {
    dispatch(getTeaTypeById(teaTypeId));
    setExpanded("panel1");
  };

  const editingTeaTypeDataFromId = useSelector(
    (state) => state.teaTypeManage.teaType.responseData
  );

  useEffect(() => {
    if (editingTeaTypeDataFromId) {
      setEditingTeatypeData(editingTeaTypeDataFromId);
    } else {
      setEditingTeatypeData(null);
      // dispatch(getAllTeaTypes());
    }
  }, [editingTeaTypeDataFromId]);
  const [expanded, setExpanded] = React.useState("panel1");
  const [showmodal, setShowmodal] = useState(false);
  const handleCloseHistory = () => setShowmodal(false);
  const [uploadedFiles, setUploadedFiles] = useState([]);
  const handleChange = (panel) => (event, isExpanded) => {
    setExpanded(isExpanded ? panel : false);
  };

  const [rows, setRows] = useState(getAllTeaType);
  useEffect(() => {
    setRows(getAllTeaType);
  }, [getAllTeaType]);

  const columns = [
    {
      name: "index",
      title: "Sr.",
    },
    {
      name: "teaTypeName",
      title: "Tea Type Name",
    },
    {
      name: "categoryCode",
      title: "Category Code",
    },
    {
      name: "categoryName",
      title: "Category Name",
    },
    {
      name: "isActive",
      title: "Status",
      getCellValue: (rows) => <StatusData data={rows} />,
    },
    {
      name: "action",
      title: "Action",
      getCellValue: (rows) => <ActionData data={rows} />,
    },
  ];
  function StatusData(data) {
    return (
      <>
        <div class="Switch">
          <div class="custom-control custom-switch">
            <input
              type="checkbox"
              class="custom-control-input"
              id="customSwitch1"
              checked={data.data.isActive === 1 ? true : false}
            />

            <label class="custom-control-label" for="customSwitch1">
              {data.data.isActive === 1 ? "Active" : "In-Active"}
            </label>
          </div>
        </div>
      </>
    );
  }

  function ActionData(data) {
    return (
      <>
        <div class="ActionBtn">
          <i
            className="fa fa-edit"
            onClick={() => handleEditClick(data.data.teaTypeId)}
          ></i>
          <i
            className="fa fa-eye"
            onClick={() => {
              setShowmodal(true);
            }}
          ></i>
        </div>
      </>
    );
  }

  const removeFile = (index) => {
    setUploadedFiles((prevFiles) => {
      const newFiles = [...prevFiles];
      newFiles.splice(index, 1);
      return newFiles;
    });
  };

  const removeAllFiles = () => {
    setUploadedFiles([]);
  };
  const handleFileUpload = (event) => {
    const files = Array.from(event.target.files);
    setUploadedFiles(files);
  };

  const renderFileTypeIcon = (file) => {
    const extension = file.name.split(".").pop().toLowerCase();

    if (extension === "pdf") {
      return <AiOutlineFilePdf />;
    } else if (
      extension === "jpg" ||
      extension === "jpeg" ||
      extension === "png"
    ) {
      return <AiOutlineFileImage />;
    } else if (extension === "txt") {
      return <AiOutlineFileText />;
    } else {
      return <AiOutlineFile />;
    }
  };

  return (
    <>
      <Modals
        title={"Tea Type Master"}
        show={open === "createTeaType" || open === "editingTeaTypeData"}
        handleClose={() => {
          setOpen("");
          setCategoryName("");
          setCategoryCode("");
          setTeaTypeName("");
          setEditingTeatypeData(null);
        }}
        size="xl"
      >
        <Accordion
          expanded={expanded === "panel1"}
          className={`${expanded === "panel1" ? "active" : ""}`}
          onChange={handleChange("panel1")}
          TransitionProps={{ unmountOnExit: true }}
        >
          <AccordionSummary
            expandIcon={<ExpandMoreIcon />}
            aria-controls="panel1a-content"
            id="panel1a-header"
          >
            <Typography>
              {editingTeaTypeData ? "Edit Tea Type" : "Create Tea Type"}
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              <div className="row">
                <div className="col-lg-12">
                  <div className="row align-items-end">
                    <div className="col-md-4">
                      <div className="FormGroup">
                        <label>Tea Type Name</label>
                        <input
                          type="text"
                          className="form-control"
                          // value={teaTypeName}
                          // onChange={(e) => setTeaTypeName(e.target.value)}
                          value={editingTeaTypeData?.teaTypeName || teaTypeName}
                          onChange={(e) =>
                            editingTeaTypeData
                              ? setEditingTeatypeData({
                                  ...editingTeaTypeData,
                                  teaTypeName: e.target.value,
                                })
                              : setTeaTypeName(e.target.value)
                          }
                        />
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="FormGroup">
                        <label>Category Code</label>
                        <input
                          type="text"
                          className="form-control"
                          // value={categoryCode}
                          // onChange={(e) => setCategoryCode(e.target.value)}
                          value={
                            editingTeaTypeData?.categoryCode || categoryCode
                          }
                          onChange={(e) =>
                            editingTeaTypeData
                              ? setEditingTeatypeData({
                                  ...editingTeaTypeData,
                                  categoryCode: e.target.value,
                                })
                              : setCategoryCode(e.target.value)
                          }
                        />
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="FormGroup">
                        <label>Category Name</label>
                        <input
                          type="text"
                          className="form-control"
                          // value={categoryName}
                          // onChange={(e) => setCategoryName(e.target.value)}
                          value={
                            editingTeaTypeData?.categoryName || categoryName
                          }
                          onChange={(e) =>
                            editingTeaTypeData
                              ? setEditingTeatypeData({
                                  ...editingTeaTypeData,
                                  categoryName: e.target.value,
                                })
                              : setCategoryName(e.target.value)
                          }
                        />
                      </div>
                    </div>
                    <div className="col-md-12">
                      <div className="FormGroup">
                        <Card className="mt-3 FileUploadBox">
                          <Card.Body>
                            <Card.Title>File Upload</Card.Title>
                            <div className="FileUpload">
                              <input
                                type="file"
                                multiple
                                onChange={handleFileUpload}
                              />
                              <button onClick={() => removeAllFiles()}>
                                Remove All
                              </button>
                            </div>
                            {/* Render file type icons based on uploaded files */}
                            {uploadedFiles.map((file, index) => (
                              <div className="UploadedFile" key={index}>
                                <div>
                                  {renderFileTypeIcon(file)}
                                  <span>{file.name}</span>
                                </div>
                                <i
                                  className="fa fa-times"
                                  onClick={() => removeFile(index)}
                                ></i>
                              </div>
                            ))}
                          </Card.Body>
                        </Card>
                      </div>
                    </div>
                    <div className="col-md-12 mt-2">
                      <textarea
                        className="form-control"
                        placeholder="Enter Remarks"
                      ></textarea>
                    </div>
                    <div className="col-md-12">
                      <div className="BtnGroup">
                        <button className="SubmitBtn" onClick={handleSubmit}>
                          {editingTeaTypeData ? "Update" : "Submit"}
                        </button>
                        <button
                          className="Clear"
                          onClick={() => {
                            setCategoryName("");
                            setCategoryCode("");
                            setTeaTypeName("");
                            setEditingTeatypeData(null);
                          }}
                        >
                          Clear
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </Typography>
          </AccordionDetails>
        </Accordion>
        <Accordion
          expanded={expanded === "panel2"}
          className={`${expanded === "panel2" ? "active" : ""}`}
          onChange={handleChange("panel2")}
        >
          <AccordionSummary
            expandIcon={<ExpandMoreIcon />}
            aria-controls="panel2a-content"
            id="panel2a-header"
          >
            <Typography>Manage Tea Type</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              <div className="row">
                <div className="col-lg-12">
                  <div className="row align-items-end">
                    <div className="col-md-4">
                      <div className="FormGroup">
                        <label>Tea Type Name</label>
                        <input type="text" className="form-control" />
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="FormGroup">
                        <label>Category Code</label>
                        <select className="form-control select-form">
                          <option>1212</option>
                        </select>
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="FormGroup">
                        <label>Category Name</label>
                        <select className="form-control select-form">
                          <option>1212</option>
                        </select>
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="FormGroup">
                        <label>Status</label>
                        <select className="form-control select-form">
                          <option>All</option>
                          <option>Active</option>
                          <option>Inactive</option>
                        </select>
                      </div>
                    </div>
                    <div className="col-md-12">
                      <div className="BtnGroup">
                        <button className="SubmitBtn">Search</button>
                        <button className="Clear">Clear</button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="row">
                <div className="col-lg-12 mt-4">
                  <div className="TableBox CreateStateMaster">
                    <TableComponent
                      columns={columns}
                      // setColumns={setColumns}
                      rows={getAllTeaType?.map((row, index) => ({
                        ...row,
                        index: index + 1,
                      }))}
                      setRows={setRows}
                      sorting={true}
                      dragdrop={false}
                      fixedColumnsOn={false}
                      resizeingCol={false}
                    />
                  </div>
                </div>
              </div>
            </Typography>
          </AccordionDetails>
        </Accordion>
        <Accordion
          expanded={expanded === "panel3"}
          className={`${expanded === "panel3" ? "active" : ""}`}
          onChange={handleChange("panel3")}
          TransitionProps={{ unmountOnExit: true }}
        >
          <AccordionSummary
            expandIcon={<ExpandMoreIcon />}
            aria-controls="panel1a-content"
            id="panel1a-header"
          >
            <Typography>Uploaded Document</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              <TableComponent
                columns={columns}
                // setColumns={setColumns}
                rows={rows}
                setRows={setRows}
                sorting={true}
                dragdrop={false}
                fixedColumnsOn={false}
                resizeingCol={false}
              />
            </Typography>
          </AccordionDetails>
        </Accordion>
      </Modals>

      {showmodal && (
        <Modal show={showmodal} onHide={handleCloseHistory} size="lg" centered>
          <Modal.Header>
            <Modal.Title>History</Modal.Title>
            <i
              className="fa fa-times CloseModal"
              onClick={handleCloseHistory}
            ></i>
          </Modal.Header>
          <Modal.Body>
            <TableComponent
              columns={columns}
              // setColumns={setColumns}
              rows={rows}
              setRows={setRows}
              sorting={true}
              dragdrop={false}
              fixedColumnsOn={false}
              resizeingCol={false}
            />
          </Modal.Body>
        </Modal>
      )}
    </>
  );
}

export default CreateTeaType;
