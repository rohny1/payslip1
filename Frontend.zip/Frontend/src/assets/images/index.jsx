export {default as FILE_ICON} from './logo.png'
export {default as ICON} from "./logo.png"
export {default as LOGINBG} from "./LoginBg.jpg"
// export {default as LOGINBG} from "./LoginBg.jpg"
