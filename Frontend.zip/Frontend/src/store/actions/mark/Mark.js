import {
  FETCH_MARK_FAILURE,
  FETCH_MARK_REQUEST,
  FETCH_MARK_SUCCESS,
} from "../../actionLabels";

export const fetchMarkRequest = () => ({
  type: FETCH_MARK_REQUEST,
});

export const fetchMarkSuccess = (data) => ({
  type: FETCH_MARK_SUCCESS,
  payload: data,
});

export const fetchMarkFailure = (error) => ({
  type: FETCH_MARK_FAILURE,
  payload: error,
});
