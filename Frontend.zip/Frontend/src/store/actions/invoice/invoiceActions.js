import {
  FETCH_INVOICE_DETAILS_FAILURE,
  FETCH_INVOICE_DETAILS_REQUEST,
  FETCH_INVOICE_DETAILS_SUCCESS,
} from "../../actionLabels/invoice/invoiceLabels";

export const fetchInvoiceDetailsRequest = () => ({
  type: FETCH_INVOICE_DETAILS_REQUEST,
});

export const fetchInvoiceDetailsSuccess = (data) => ({
  type: FETCH_INVOICE_DETAILS_SUCCESS,
  payload: data,
});

export const fetchInvoiceDetailsFailure = (error) => ({
  type: FETCH_INVOICE_DETAILS_FAILURE,
  payload: error,
});
