import * as actionLabels from "../../actionLabels/index";

// GET ALL PLANTATION
export const getAllPlantationAction = () => {
  return {
    type: actionLabels.GET_ALL_PLANTATION,
  };
};

export const getAllPlantationActionSuccess = (plantations) => {
  return {
    type: actionLabels.GET_ALL_PLANTATION_SUCCESS,
    payload: plantations,
  };
};

export const getAllPlantationActionFail = (error) => ({
  type: actionLabels.GET_ALL_PLANTATION_FAIL,
  payload: error,
});

// CREATE PLANTATION
export const createPlantationAction = (plantationData) => {
  return {
    type: actionLabels.CREATE_PLANTATION,
    payload: plantationData,
  };
};

export const createPlantationActionSuccess = () => {
  return {
    type: actionLabels.CREATE_PLANTATION_SUCCESS,
  };
};

export const createPlantationActionFail = (error) => ({
  type: actionLabels.CREATE_PLANTATION_FAIL,
  payload: error,
});

// UPDATE PLANTATION
export const updatePlantationAction = (plantationData) => {
  return {
    type: actionLabels.UPDATE_PLANTATION,
    payload: plantationData,
  };
};

export const updatePlantationActionSuccess = () => {
  return {
    type: actionLabels.UPDATE_PLANTATION_SUCCESS,
  };
};

export const updatePlantationActionFail = (error) => ({
  type: actionLabels.UPDATE_PLANTATION_FAIL,
  payload: error,
});

// SEARCH PLANTATION
export const searchPlantationAction = (searchCriteria) => {
  return {
    type: actionLabels.SEARCH_PLANTATION,
    payload: searchCriteria,
  };
};

export const searchPlantationActionSuccess = (searchResult) => {
  return {
    type: actionLabels.SEARCH_PLANTATION_SUCCESS,
    payload: searchResult,
  };
};

export const searchPlantationActionFail = (error) => ({
  type: actionLabels.SEARCH_PLANTATION_FAIL,
  payload: error,
});

// GET PLANTATION BY STATUS
export const getPlantationByStatusAction = (status) => {
  return {
    type: actionLabels.GET_PLANTATION_BY_STATUS,
    payload: status,
  };
};

export const getPlantationByStatusActionSuccess = (plantations) => {
  return {
    type: actionLabels.GET_PLANTATION_BY_STATUS_SUCCESS,
    payload: plantations,
  };
};

export const getPlantationByStatusActionFail = (error) => ({
  type: actionLabels.GET_PLANTATION_BY_STATUS_FAIL,
  payload: error,
});

// GET PLANTATION BY ID
export const getPlantationByIdAction = (plantationId) => {
  return {
    type: actionLabels.GET_PLANTATION_BY_ID,
    payload: plantationId,
  };
};

export const getPlantationByIdActionSuccess = (plantation) => {
  return {
    type: actionLabels.GET_PLANTATION_BY_ID_SUCCESS,
    payload: plantation,
  };
};

export const getPlantationByIdActionFail = (error) => ({
  type: actionLabels.GET_PLANTATION_BY_ID_FAIL,
  payload: error,
});
