import * as actionLabels from "../../actionLabels";

// GET ALL REVENUE
export const getAllRevenueAction = () => {
  return {
    type: actionLabels.GET_ALL_REVENUE,
  };
};

export const getAllRevenueActionSuccess = (revenueData) => {
  return {
    type: actionLabels.GET_ALL_REVENUE_SUCCESS,
    payload: revenueData,
  };
};

export const getAllRevenueActionFail = (error) => ({
  type: actionLabels.GET_ALL_REVENUE_FAIL,
  payload: error,
});

// CREATE REVENUE
export const createRevenueAction = (revenueData) => {
  return {
    type: actionLabels.CREATE_REVENUE,
    payload: revenueData,
  };
};

export const createRevenueActionSuccess = (createdRevenue) => {
  return {
    type: actionLabels.CREATE_REVENUE_SUCCESS,
    payload: createdRevenue,
  };
};

export const createRevenueActionFail = (error) => ({
  type: actionLabels.CREATE_REVENUE_FAIL,
  payload: error,
});

// UPDATE REVENUE
export const updateRevenueAction = (revenueId, updatedRevenueData) => {
  return {
    type: actionLabels.UPDATE_REVENUE,
    payload: {
      revenueId,
      updatedRevenueData,
    },
  };
};

export const updateRevenueActionSuccess = (updatedRevenue) => {
  return {
    type: actionLabels.UPDATE_REVENUE_SUCCESS,
    payload: updatedRevenue,
  };
};

export const updateRevenueActionFail = (error) => ({
  type: actionLabels.UPDATE_REVENUE_FAIL,
  payload: error,
});

// SEARCH REVENUE
export const searchRevenueAction = (searchCriteria) => {
  return {
    type: actionLabels.SEARCH_REVENUE,
    payload: searchCriteria,
  };
};

export const searchRevenueActionSuccess = (searchedRevenueData) => {
  return {
    type: actionLabels.SEARCH_REVENUE_SUCCESS,
    payload: searchedRevenueData,
  };
};

export const searchRevenueActionFail = (error) => ({
  type: actionLabels.SEARCH_REVENUE_FAIL,
  payload: error,
});

// GET REVENUE BY STATUS
export const getRevenueByStatusAction = (status) => {
  return {
    type: actionLabels.GET_REVENUE_BY_STATUS,
    payload: status,
  };
};

export const getRevenueByStatusActionSuccess = (revenueData) => {
  return {
    type: actionLabels.GET_REVENUE_BY_STATUS_SUCCESS,
    payload: revenueData,
  };
};

export const getRevenueByStatusActionFail = (error) => ({
  type: actionLabels.GET_REVENUE_BY_STATUS_FAIL,
  payload: error,
});

// GET REVENUE BY ID
export const getRevenueByIdAction = (revenueId) => {
  return {
    type: actionLabels.GET_REVENUE_BY_ID,
    payload: revenueId,
  };
};

export const getRevenueByIdActionSuccess = (revenueData) => {
  return {
    type: actionLabels.GET_REVENUE_BY_ID_SUCCESS,
    payload: revenueData,
  };
};

export const getRevenueByIdActionFail = (error) => ({
  type: actionLabels.GET_REVENUE_BY_ID_FAIL,
  payload: error,
});
