import * as actionTypes from "../../actionLabels/index";

const initialState = {
  getAllAuctionCenter: [],
  createdAuctionCenter: null,
  updatedAuctionCenter: null,
  searchResults: [],
  auctionCentersByStatus: [],
  auctionCenterById: [],
  error: null,
};

const getAuctionCenterReducer = (state = initialState, action) => {
  // {
  //   console.log("action:reducer");
  //   console.log("dataReduser::", action.type);
  // }
  switch (action.type) {
    case actionTypes.GET_ALL_AUCTION_CENTER_SUCCESS:
      return {
        ...state,
        getAllAuctionCenter: action.payload,
        error: null,
      };
    case actionTypes.GET_ALL_AUCTION_CENTER_FAIL:
      return {
        ...state,
        getAllAuctionCenter: [],
        error: action.payload,
      };
    case actionTypes.CREATE_AUCTION_CENTER_SUCCESS:
      return {
        ...state,
        createdAuctionCenter: action.payload,
        error: null,
      };

    case actionTypes.CREATE_AUCTION_CENTER_FAIL:
      return {
        ...state,
        error: action.payload,
      };
    case actionTypes.UPDATE_AUCTION_CENTER_SUCCESS:
      return {
        ...state,
        updatedAuctionCenter: action.payload,
        error: null,
      };

    case actionTypes.UPDATE_AUCTION_CENTER_FAIL:
      return {
        ...state,
        error: action.payload,
      };
    case actionTypes.SEARCH_AUCTION_CENTER_SUCCESS:
      return {
        ...state,
        searchResults: action.payload,
        error: null,
      };

    case actionTypes.SEARCH_AUCTION_CENTER_FAIL:
      return {
        ...state,
        error: action.payload,
      };
    case actionTypes.GET_AUCTION_CENTER_BY_STATUS_SUCCESS:
      return {
        ...state,
        auctionCentersByStatus: action.payload,
        error: null,
      };

    case actionTypes.GET_AUCTION_CENTER_BY_STATUS_FAIL:
      return {
        ...state,
        error: action.payload,
      };

    case actionTypes.GET_AUCTION_CENTER_BY_ID_SUCCESS:
      return {
        ...state,
        auctionCenterById: action.payload,
        error: null,
      };

    case actionTypes.GET_AUCTION_CENTER_BY_ID_FAIL:
      return {
        ...state,
        error: action.payload,
      };
    default:
      return state;
  }
};

export default getAuctionCenterReducer;
