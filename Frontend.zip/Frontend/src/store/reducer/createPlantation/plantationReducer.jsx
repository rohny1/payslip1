import * as actionTypes from "../../actionLabels";

const initialState = {
  allPlantations: [],
  createdPlantation: null,
  updatedPlantation: null,
  searchedPlantations: [],
  plantationByStatus: [],
  plantationById: null,
  error: null,
};

const plantationReducer = (state = initialState, action) => {
  switch (action.type) {
    case actionTypes.GET_ALL_PLANTATION_SUCCESS:
      return {
        ...state,
        allPlantations: action.payload,
        error: null,
      };

    case actionTypes.GET_ALL_PLANTATION_FAIL:
      return {
        ...state,
        allPlantations: [],
        error: action.payload,
      };

    case actionTypes.CREATE_PLANTATION_SUCCESS:
      return {
        ...state,
        createdPlantation: action.payload,
        error: null,
      };

    case actionTypes.CREATE_PLANTATION_FAIL:
      return {
        ...state,
        createdPlantation: null,
        error: action.payload,
      };

    case actionTypes.UPDATE_PLANTATION_SUCCESS:
      return {
        ...state,
        updatedPlantation: action.payload,
        error: null,
      };

    case actionTypes.UPDATE_PLANTATION_FAIL:
      return {
        ...state,
        updatedPlantation: null,
        error: action.payload,
      };

    case actionTypes.SEARCH_PLANTATION_SUCCESS:
      return {
        ...state,
        searchedPlantations: action.payload,
        error: null,
      };

    case actionTypes.SEARCH_PLANTATION_FAIL:
      return {
        ...state,
        searchedPlantations: [],
        error: action.payload,
      };

    case actionTypes.GET_PLANTATION_BY_STATUS_SUCCESS:
      return {
        ...state,
        plantationByStatus: action.payload,
        error: null,
      };

    case actionTypes.GET_PLANTATION_BY_STATUS_FAIL:
      return {
        ...state,
        plantationByStatus: [],
        error: action.payload,
      };

    case actionTypes.GET_PLANTATION_BY_ID_SUCCESS:
      return {
        ...state,
        plantationById: action.payload,
        error: null,
      };

    case actionTypes.GET_PLANTATION_BY_ID_FAIL:
      return {
        ...state,
        plantationById: null,
        error: action.payload,
      };

    default:
      return state;
  }
};

export default plantationReducer;
