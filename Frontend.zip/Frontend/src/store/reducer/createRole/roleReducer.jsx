import * as actionTypes from "../../actionLabels/index";

const initialState = {
  allRoles: [],
  searchedRoles: [],
  roleById: [],
  error: null,
};

const roleReducer = (state = initialState, action) => {
  switch (action.type) {
    case actionTypes.GET_ALL_ROLES_SUCCESS:
      return {
        ...state,
        allRoles: action.payload,
        error: null,
      };

    case actionTypes.GET_ALL_ROLES_FAIL:
      return {
        ...state,
        allRoles: [],
        error: action.payload,
      };

    case actionTypes.CREATE_ROLE_SUCCESS:
      return {
        ...state,
        error: null,
      };

    case actionTypes.CREATE_ROLE_FAIL:
      return {
        ...state,
        error: action.payload,
      };

    case actionTypes.UPDATE_ROLE_SUCCESS:
      return {
        ...state,
        error: null,
      };

    case actionTypes.UPDATE_ROLE_FAIL:
      return {
        ...state,
        error: action.payload,
      };

    case actionTypes.SEARCH_ROLE_SUCCESS:
      return {
        ...state,
        searchedRoles: action.payload,
        error: null,
      };

    case actionTypes.SEARCH_ROLE_FAIL:
      return {
        ...state,
        searchedRoles: [],
        error: action.payload,
      };

    case actionTypes.GET_ROLE_BY_STATUS_SUCCESS:
      return {
        ...state,
        allRoles: action.payload,
        error: null,
      };

    case actionTypes.GET_ROLE_BY_STATUS_FAIL:
      return {
        ...state,
        allRoles: [],
        error: action.payload,
      };

    case actionTypes.GET_ROLE_BY_ID_SUCCESS:
      return {
        ...state,
        roleById: action.payload,
        error: null,
      };

    case actionTypes.GET_ROLE_BY_ID_FAIL:
      return {
        ...state,
        roleById: [],
        error: action.payload,
      };

    default:
      return state;
  }
};

export default roleReducer;
