// commonSaga.js
import { takeLatest, put, call } from "redux-saga/effects";
import axiosMain from "../../../http/axios/axios_main";
import {
  fetchInvoiceDetailsFailure,
  fetchInvoiceDetailsSuccess,
} from "../../actions/invoice/invoiceActions";
import { FETCH_INVOICE_DETAILS_REQUEST } from "../../actionLabels/invoice/invoiceLabels";

// Worker Saga: Makes the API call when the FETCH_INVOICE_DETAILS_REQUEST action is dispatched
function* fetchInvoiceDetailsSaga() {
  try {
    const response = yield call(
      axiosMain.get,
      "InvoiceDetails/GetInvoiceDetails"
    );
    yield put(fetchInvoiceDetailsSuccess(response.data));
  } catch (error) {
    yield put(fetchInvoiceDetailsFailure(error.message));
  }
}

// Watcher Saga: Watches for the FETCH_INVOICE_DETAILS_REQUEST action and calls the worker saga
export function* watchFetchInvoiceDetails() {
  yield takeLatest(FETCH_INVOICE_DETAILS_REQUEST, fetchInvoiceDetailsSaga);
}
