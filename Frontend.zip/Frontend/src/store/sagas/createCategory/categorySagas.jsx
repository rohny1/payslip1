import { all, call, put, takeEvery } from "redux-saga/effects";
import axiosMain from "../../../http/axios/axios_main";
import {
  GET_ALL_CATEGORIES,
  CREATE_CATEGORY,
  UPDATE_CATEGORY,
  SEARCH_CATEGORIES,
  GET_CATEGORIES_BY_STATUS,
  GET_CATEGORY_BY_ID,
} from "../../actionLabels";
import {
  getAllCategoriesAction,
  getAllCategoriesSuccess,
  getAllCategoriesFail,
  createCategorySuccess,
  createCategoryFail,
  updateCategorySuccess,
  updateCategoryFail,
  searchCategoriesSuccess,
  searchCategoriesFail,
  getCategoriesByStatusSuccess,
  getCategoriesByStatusFail,
  getCategoryByIdSuccess,
  getCategoryByIdFail,
} from "../../actions";

// function* getAllCategorySaga() {
//   try {
//     const response = yield call(
//       axiosMain.get,
//       "admin/Category/search?pageNo=0&pageSize=10&userId=0&categoryId=0&categoryName=string&categoryCode=string&isActive=0&uploadDocumentRemarks=string&sessionUserId=0"
//     );
//     yield put(roleActions.getCategorySuccess(response.data));
//   } catch (error) {
//     yield put(roleActions.getCategoryFail(error));
//   }
// }

// Generator function to handle the GET_ALL_CATEGORIES action
function* getAllCategories() {
  try {
    const response = yield call(
      axiosMain.get,
      "admin/Category/search?categoryName=string&categoryCode=string"
    );
    yield put(getAllCategoriesSuccess(response.data));
  } catch (error) {
    yield put(getAllCategoriesFail(error.message));
  }
}

// Generator function to handle the CREATE_CATEGORY action
function* createCategory(action) {
  // console.log("CREATE_CATEGORY::", action.payload.categoryData);
  try {
    const response = yield call(
      axiosMain.post,
      `admin/Category/create`,
      action.payload.categoryData
    );
    if (response.status === 201) {
      yield put(createCategorySuccess());
      yield put(getAllCategoriesAction());
    } else {
      yield put(createCategoryFail("Failed to create category"));
    }
  } catch (error) {
    yield put(createCategoryFail(error.message));
  }
}
// Generator function to handle the UPDATE_CATEGORY action
function* updateCategory(action) {
  try {
    const response = yield call(
      axiosMain.put,
      `admin/Category/update/`,
      action.payload.categoryId,
      action.payload.updatedData
    );
    if (response.status === 200) {
      yield put(updateCategorySuccess());
    } else {
      yield put(updateCategoryFail("Failed to update category"));
    }
  } catch (error) {
    yield put(updateCategoryFail(error.message));
  }
}

// Generator function to handle the SEARCH_CATEGORIES action
function* searchCategories(action) {
  try {
    const response = yield call(
      axiosMain.post,
      `admin/Category/search`,
      action.payload.searchCriteria
    );
    yield put(searchCategoriesSuccess(response.data));
  } catch (error) {
    yield put(searchCategoriesFail(error.message));
  }
}

// Generator function to handle the GET_CATEGORIES_BY_STATUS action
function* getCategoriesByStatus(action) {
  try {
    const response = yield call(
      axiosMain.get,
      `admin/Category/getAllCategory/`,
      action.payload.status
    );
    yield put(getCategoriesByStatusSuccess(response.data));
  } catch (error) {
    yield put(getCategoriesByStatusFail(error.message));
  }
}

// Generator function to handle the GET_CATEGORY_BY_ID action
function* getCategoryById(action) {
  try {
    const response = yield call(
      axiosMain.get,
      `admin/Category/getById/`,
      action.payload.categoryId
    );
    yield put(getCategoryByIdSuccess(response.data));
  } catch (error) {
    yield put(getCategoryByIdFail(error.message));
  }
}

export function* categorysSaga() {
  yield all([
    takeEvery(GET_ALL_CATEGORIES, getAllCategories),
    takeEvery(CREATE_CATEGORY, createCategory),
    takeEvery(UPDATE_CATEGORY, updateCategory),
    takeEvery(SEARCH_CATEGORIES, searchCategories),
    takeEvery(GET_CATEGORIES_BY_STATUS, getCategoriesByStatus),
    takeEvery(GET_CATEGORY_BY_ID, getCategoryById),
  ]);
}
