import { all, call, put, takeEvery } from "redux-saga/effects";
import axiosMain from "../../../http/axios/axios_main";
import {
  GET_ALL_STATE,
  GET_ALL_STATE_WITH_STATUS,
  GET_STATE_BY_ID,
  CREATE_STATE,
  UPDATE_STATE,
  SEARCH_STATE,
} from "../../actionLabels";
import {
  getAllStateActionFail,
  getAllStateActionSuccess,
  getAllStateWithStatusActionSuccess,
  getAllStateWithStatusActionFail,
  getStateByIdActionSuccess,
  getStateByIdActionFail,
  createStateActionSuccess,
  createStateActionFail,
  getAllStateAction,
  updateStateActionSuccess,
  updateStateActionFail,
  searchStateActionSuccess,
  searchStateActionFail,
} from "../../actions";
function* getAllStateSaga() {
  try {
    const response = yield call(axiosMain.get, "admin/state/getAll");
    if (response.status == 200) {
      yield put(getAllStateActionSuccess(response.data));
    } else {
      yield put(getAllStateActionFail(error));
    }
  } catch (error) {
    yield put(getAllStateActionFail(error));
  }
}

function* getAllStateWithStatusSaga(action) {
  try {
    const isActive = action.payload;
    const response = yield call(
      axiosMain.get,
      `admin/state/getAll/${isActive}/10/1`,
      isActive
    );
    if (response.status == 200) {
      yield put(getAllStateWithStatusActionSuccess(response.data));
    } else {
      yield put(getAllStateWithStatusActionFail(error.message));
    }
  } catch (error) {
    yield put(getAllStateWithStatusActionFail(error.message));
  }
}

//Fetch state by ID
function* getStateByIdSaga(action) {
  try {
    const stateId = action.payload;
    const stateData = yield call(axiosMain.get, `admin/state/get/${stateId}`);

    if (stateData.status == 200) {
      yield put(getStateByIdActionSuccess(stateData.data));
    } else {
      yield put(getStateByIdActionFail(stateData.data.message));
    }
  } catch (error) {
    yield put(getStateByIdActionFail(error));
  }
}

//creating a new state
function* createStateSaga(action) {
  try {
    const newStateData = action.payload;
    const createdState = yield call(
      axiosMain.post,
      `admin/state/create`,
      newStateData
    );
    if (createdState.status == 200) {
      yield put(createStateActionSuccess(createdState));
      yield put(getAllStateAction());
    } else {
      console.log("error:", createdState);
      yield put(createStateActionFail(error));
    }
  } catch (error) {
    yield put(createStateActionFail(error));
  }
}

//updating a state
function* updateStateSaga(action) {
  console.log("updating state", action.payload);
  try {
    const { updatedStateData } = action.payload;
    const updatedState = yield call(
      axiosMain.post,
      `admin/state/update`,
      updatedStateData
    );
    if (updatedState.status == 200) {
      yield put(updateStateActionSuccess(updatedState));
      yield put(getAllStateAction());
    } else {
      yield put(createStateActionFail(error));
    }
  } catch (error) {
    yield put(updateStateActionFail(error));
  }
}

//searching a state
function* searchStateSaga(action) {
  try {
    const searchTerm = action.payload;
    const searchResults = yield call(
      axiosMain.get`/admin/state/searchState`,
      searchTerm
    );
    if (searchResults.status == 200) {
      yield put(searchStateActionSuccess(searchResults));
    } else {
      yield put(searchStateActionFail(error));
    }
  } catch (error) {
    yield put(searchStateActionFail(error));
  }
}

function* stateSaga() {
  yield all([
    yield takeEvery(GET_ALL_STATE, getAllStateSaga),
    yield takeEvery(GET_ALL_STATE_WITH_STATUS, getAllStateWithStatusSaga),
    yield takeEvery(GET_STATE_BY_ID, getStateByIdSaga),
    yield takeEvery(CREATE_STATE, createStateSaga),
    yield takeEvery(UPDATE_STATE, updateStateSaga),
    yield takeEvery(SEARCH_STATE, searchStateSaga),
  ]);
}

export default stateSaga;
