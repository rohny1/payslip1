import { all, call, put, takeEvery } from "redux-saga/effects";
import axiosMain from "../../../http/axios/axios_main";
import {
  GET_ALL_PLANTATION,
  CREATE_PLANTATION,
  UPDATE_PLANTATION,
  SEARCH_PLANTATION,
  GET_PLANTATION_BY_STATUS,
  GET_PLANTATION_BY_ID,
} from "../../actionLabels";
import {
  getAllPlantationAction,
  getAllPlantationActionSuccess,
  getAllPlantationActionFail,
  createPlantationActionSuccess,
  createPlantationActionFail,
  updatePlantationActionSuccess,
  updatePlantationActionFail,
  searchPlantationActionSuccess,
  searchPlantationActionFail,
  getPlantationByStatusActionSuccess,
  getPlantationByStatusActionFail,
  getPlantationByIdActionSuccess,
  getPlantationByIdActionFail,
} from "../../actions";

// GET ALL PLANTATION
function* getAllPlantation() {
  try {
    const response = yield call(
      axiosMain.get,
      `admin/plantation/getAllPlantationDrop`
    );
    yield put(getAllPlantationActionSuccess(response.data));
  } catch (error) {
    yield put(getAllPlantationActionFail(error));
  }
}

// CREATE PLANTATION
function* createPlantation(action) {
  try {
    const response = yield call(
      axiosMain.post,
      `admin/plantation/savePlantation`,
      action.payload
    );
    yield put(createPlantationActionSuccess(response.data));
    yield put(getAllPlantationAction());
  } catch (error) {
    yield put(createPlantationActionFail(error));
  }
}

// UPDATE PLANTATION
function* updatePlantation(action) {
  try {
    const response = yield call(
      axiosMain.post,
      `admin/plantation/updatePlantation`,
      action.payload
    );
    yield put(updatePlantationActionSuccess(response.data));
  } catch (error) {
    yield put(updatePlantationActionFail(error));
  }
}

// SEARCH PLANTATION
function* searchPlantation(action) {
  try {
    const response = yield call(
      axiosMain.get,
      `admin/plantation/searchPlantation`,
      action.payload
    );
    yield put(searchPlantationActionSuccess(response.data));
  } catch (error) {
    yield put(searchPlantationActionFail(error));
  }
}

// GET PLANTATION BY STATUS
function* getPlantationByStatus(action) {
  try {
    const response = yield call(
      axiosMain.get,
      `admin/plantation/getAllPlantation/`,
      action.payload
    );
    yield put(getPlantationByStatusActionSuccess(response.data));
  } catch (error) {
    yield put(getPlantationByStatusActionFail(error));
  }
}

// GET PLANTATION BY ID
function* getPlantationById(action) {
  try {
    const response = yield call(
      axiosMain.get,
      `admin/plantation/getPlantation/`,
      action.payload
    );
    yield put(getPlantationByIdActionSuccess(response.data));
  } catch (error) {
    yield put(getPlantationByIdActionFail(error));
  }
}

export function* plantationSaga() {
  yield all([
    yield takeEvery(GET_ALL_PLANTATION, getAllPlantation),
    yield takeEvery(CREATE_PLANTATION, createPlantation),
    yield takeEvery(UPDATE_PLANTATION, updatePlantation),
    yield takeEvery(SEARCH_PLANTATION, searchPlantation),
    yield takeEvery(GET_PLANTATION_BY_STATUS, getPlantationByStatus),
    yield takeEvery(GET_PLANTATION_BY_ID, getPlantationById),
  ]);
}

export default plantationSaga;
