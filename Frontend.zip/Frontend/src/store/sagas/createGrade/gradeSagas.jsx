import { all, call, put, takeEvery } from "redux-saga/effects";
import axiosMain from "../../../http/axios/axios_main";
import {
  GET_ALL_GRADES,
  CREATE_GRADE,
  UPDATE_GRADE,
  SEARCH_GRADE,
  GET_GRADES_BY_STATUS,
  GET_GRADE_BY_ID,
} from "../../actionLabels";
import {
  getAllGrades,
  getAllGradesSuccess,
  getAllGradesFail,
  createGradeSuccess,
  createGradeFail,
  updateGradeSuccess,
  updateGradeFail,
  searchGradeSuccess,
  searchGradeFail,
  getGradesByStatusSuccess,
  getGradesByStatusFail,
  getGradeByIdSuccess,
  getGradeByIdFail,
} from "../../actions";

// Worker saga for getting all grades
function* getAllGradesSaga() {
  try {
    const grades = yield call(axiosMain.get, "admin/grade/getAll");
    yield put(getAllGradesSuccess(grades.data));
  } catch (error) {
    yield put(getAllGradesFail(error.message));
  }
}

// Worker saga for creating a new grade
function* createGradeSaga(action) {
  try {
    yield call(axiosMain.post, `admin/grade/create`, action.payload);
    yield put(createGradeSuccess());
    yield put(getAllGrades());
    // Optionally, dispatch another action to handle any additional logic after successful creation
  } catch (error) {
    yield put(createGradeFail(error.message));
  }
}

// Worker saga for updating a grade
function* updateGradeSaga(action) {
  console.log("updateGradeSaga:", action.payload);
  try {
    yield call(axiosMain.post, `admin/grade/update`, action.payload);
    yield put(updateGradeSuccess());
    yield put(getAllGrades());
    // Optionally, dispatch another action to handle any additional logic after successful update
  } catch (error) {
    yield put(updateGradeFail(error.message));
  }
}

// Worker saga for searching grades
function* searchGradeSaga(action) {
  try {
    const searchResults = yield call(
      axiosMain.get,
      "admin/grade/search",
      action.payload
    );
    yield put(searchGradeSuccess(searchResults));
  } catch (error) {
    yield put(searchGradeFail(error.message));
  }
}

// Worker saga for getting grades by status
function* getGradesByStatusSaga(action) {
  try {
    const grades = yield call(
      axiosMain.get,
      "admin/grade/getAll",
      action.payload
    );
    yield put(getGradesByStatusSuccess(grades));
  } catch (error) {
    yield put(getGradesByStatusFail(error.message));
  }
}

// Worker saga for getting a grade by ID
function* getGradeByIdSaga(action) {
  try {
    const grade = yield call(
      axiosMain.get,
      `admin/grade/get/${action.payload}`
    );
    yield put(getGradeByIdSuccess(grade.data));
  } catch (error) {
    yield put(getGradeByIdFail(error.message));
  }
}

export function* gradeSagas() {
  yield all([
    takeEvery(GET_ALL_GRADES, getAllGradesSaga),
    takeEvery(CREATE_GRADE, createGradeSaga),
    takeEvery(UPDATE_GRADE, updateGradeSaga),
    takeEvery(SEARCH_GRADE, searchGradeSaga),
    takeEvery(GET_GRADES_BY_STATUS, getGradesByStatusSaga),
    takeEvery(GET_GRADE_BY_ID, getGradeByIdSaga),
  ]);
}
