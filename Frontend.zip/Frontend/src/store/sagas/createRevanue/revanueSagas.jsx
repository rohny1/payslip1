import { all, call, put, takeEvery } from "redux-saga/effects";
import axiosMain from "../../../http/axios/axios_main";
import {
  GET_ALL_REVENUE,
  CREATE_REVENUE,
  UPDATE_REVENUE,
  SEARCH_REVENUE,
  GET_REVENUE_BY_STATUS,
  GET_REVENUE_BY_ID,
} from "../../actionLabels";
import {
  getAllRevenueAction,
  getAllRevenueActionSuccess,
  getAllRevenueActionFail,
  createRevenueActionSuccess,
  createRevenueActionFail,
  updateRevenueActionSuccess,
  updateRevenueActionFail,
  searchRevenueActionSuccess,
  searchRevenueActionFail,
  getRevenueByStatusActionSuccess,
  getRevenueByStatusActionFail,
  getRevenueByIdActionSuccess,
  getRevenueByIdActionFail,
} from "../../actions";

// function* fetchRdmSaga() {
//   try {
//     const response = yield call(
//       axiosMain.get,
//       "admin/revenue/searchRevenue?plantationDistrict=&stateName=&revenueDistrictName="
//     );
//     yield put(getAllRdm.fetchRdmSuccess(response.data));
//   } catch (error) {
//     yield put(getAllRdm.fetchRdmFail(error));
//   }
// }
// Mock API calls for demonstration purposes

function* getAllRevenueSaga() {
  try {
    const revenueList = yield call(
      axiosMain.get,
      "admin/revenue/searchRevenue?plantationDistrict=&stateName=&revenueDistrictName="
    );
    yield put(getAllRevenueActionSuccess(revenueList.data));
  } catch (error) {
    yield put(getAllRevenueActionFail(error.message));
  }
}

function* createRevenueSaga(action) {
  try {
    const createdRevenue = yield call(
      axiosMain.post,
      `admin/revenue/saveRevenue`,
      action.payload
    );
    yield put(createRevenueActionSuccess(createdRevenue));
    yield put(getAllRevenueAction());
  } catch (error) {
    yield put(createRevenueActionFail(error.message));
  }
}

function* updateRevenueSaga(action) {
  try {
    const updatedRevenue = yield call(
      axiosMain.put,
      `admin/revenue/updateRevenue`,
      action.payload.id,
      action.payload.data
    );
    yield put(updateRevenueActionSuccess(updatedRevenue));
  } catch (error) {
    yield put(updateRevenueActionFail(error.message));
  }
}

function* searchRevenueSaga(action) {
  try {
    const searchedRevenue = yield call(
      axiosMain.get,
      `admin/revenue/searchRevenue`,
      action.payload
    );
    yield put(searchRevenueActionSuccess(searchedRevenue));
  } catch (error) {
    yield put(searchRevenueActionFail(error.message));
  }
}

function* getRevenueByStatusSaga(action) {
  try {
    const revenueByStatus = yield call(
      axiosMain.get,
      `admin/revenue/getAllRevenue/`,
      action.payload
    );
    yield put(getRevenueByStatusActionSuccess(revenueByStatus));
  } catch (error) {
    yield put(getRevenueByStatusActionFail(error.message));
  }
}

function* getRevenueByIdSaga(action) {
  try {
    const revenueById = yield call(
      axiosMain.get,
      `admin/revenue/getRevenue/`,
      action.payload
    );
    yield put(getRevenueByIdActionSuccess(revenueById));
  } catch (error) {
    yield put(getRevenueByIdActionFail(error.message));
  }
}

export function* revanueSaga() {
  yield all([
    takeEvery(GET_ALL_REVENUE, getAllRevenueSaga),
    takeEvery(CREATE_REVENUE, createRevenueSaga),
    takeEvery(UPDATE_REVENUE, updateRevenueSaga),
    takeEvery(SEARCH_REVENUE, searchRevenueSaga),
    takeEvery(GET_REVENUE_BY_STATUS, getRevenueByStatusSaga),
    takeEvery(GET_REVENUE_BY_ID, getRevenueByIdSaga),
  ]);
}

export default revanueSaga;
