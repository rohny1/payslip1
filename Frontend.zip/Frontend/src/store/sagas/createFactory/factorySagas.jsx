import { all, call, put, takeEvery } from "redux-saga/effects";
import axiosMain from "../../../http/axios/axios_main";
import {
  GET_ALL_FACTORY_TYPES,
  CREATE_FACTORY_TYPE,
  UPDATE_FACTORY_TYPE,
  SEARCH_FACTORY_TYPE,
  GET_FACTORY_TYPES_BY_STATUS,
  GET_FACTORY_TYPE_BY_ID,
} from "../../actionLabels";
import {
  getAllFactoryTypes,
  getAllFactoryTypesSuccess,
  getAllFactoryTypesFail,
  createFactoryTypeSuccess,
  createFactoryTypeFail,
  updateFactoryTypeSuccess,
  updateFactoryTypeFail,
  searchFactoryTypeSuccess,
  searchFactoryTypeFail,
  getFactoryTypesByStatusSuccess,
  getFactoryTypesByStatusFail,
  getFactoryTypeByIdSuccess,
  getFactoryTypeByIdFail,
} from "../../actions";

// Function to fetch all factory types
function* getAllFactoryTypesSaga() {
  try {
    const factoryTypes = yield call(axiosMain.get, "admin/factorytype/getAll");
    yield put(getAllFactoryTypesSuccess(factoryTypes.data));
  } catch (error) {
    yield put(getAllFactoryTypesFail(error.message));
  }
}
// Function to create a new factory type
function* createFactoryTypeSaga(action) {
  try {
    yield call(axiosMain.post, `admin/factorytype/create`, action.payload);

    yield put(createFactoryTypeSuccess());
    yield put(getAllFactoryTypes());
  } catch (error) {
    yield put(createFactoryTypeFail(error.message));
  }
}
// Function to update a factory type
function* updateFactoryTypeSaga(action) {
  try {
    const { updatedData } = action.payload;

    yield call(axiosMain.post, `admin/factorytype/update`, updatedData);
    yield put(updateFactoryTypeSuccess());
    yield put(getAllFactoryTypes());
  } catch (error) {
    yield put(updateFactoryTypeFail(error.message));
  }
}
// Function to search for factory types based on criteria
function* searchFactoryTypeSaga(action) {
  try {
    const { searchCriteria } = action.payload;
    const searchResults = yield call(
      axiosMain.get`/admin/factorytype/search`,
      searchCriteria
    );
    yield put(searchFactoryTypeSuccess(searchResults));
  } catch (error) {
    yield put(searchFactoryTypeFail(error.message));
  }
}

// Function to get factory types by status
function* getFactoryTypesByStatusSaga(action) {
  try {
    const { status } = action.payload;

    const factoryTypes = yield call(
      axiosMain.get,
      `admin/factorytype/getAll`,
      status
    );

    yield put(getFactoryTypesByStatusSuccess(factoryTypes));
  } catch (error) {
    yield put(getFactoryTypesByStatusFail(error.message));
  }
}

// Function to get factory type by ID
function* getFactoryTypeByIdSaga(action) {
  try {
    const factoryType = yield call(
      axiosMain.get,
      `admin/factorytype/get/${action.payload}`
    );
    yield put(getFactoryTypeByIdSuccess(factoryType.data));
  } catch (error) {
    yield put(getFactoryTypeByIdFail(error.message));
  }
}

export function* factorysSagas() {
  yield all([
    takeEvery(GET_ALL_FACTORY_TYPES, getAllFactoryTypesSaga),
    takeEvery(CREATE_FACTORY_TYPE, createFactoryTypeSaga),
    takeEvery(UPDATE_FACTORY_TYPE, updateFactoryTypeSaga),
    takeEvery(SEARCH_FACTORY_TYPE, searchFactoryTypeSaga),
    takeEvery(GET_FACTORY_TYPES_BY_STATUS, getFactoryTypesByStatusSaga),
    takeEvery(GET_FACTORY_TYPE_BY_ID, getFactoryTypeByIdSaga),
  ]);
}
