/* eslint-disable import/prefer-default-export */
import { all } from "redux-saga/effects";

import dummySagas from "./dummy/dummy";
import authSagas from "./auth/auth";
import toggleSaga from "./toggle/toggle";
import auctionCenterRootSagas from "./auction/auction";
import saleSagas from "./sale/sale";
import teaType from "./teaType/TeaType";
import { markData } from "./mark/Mark";
import { watchFetchWarehouseUser } from "./warehouse/warehouse";
import { watchFetchGrade } from "./grade/Grade";
import { watchFetchCategory } from "./bindCategory/bindcategory";
import { allAuctionCenterSaga } from "./createAuctionCenter/auctionCenterSagas";
import { TeaTypesSaga } from "./createTeaType/teatypeSagas";
import { gradeSagas } from "./createGrade/gradeSagas";
import { factorysSagas } from "./createFactory/factorySagas";
import { subTeaTypesSaga } from "./createSubTeaType/subTeaTypeSagas";
import { roleSaga } from "./createRole/roleSagas";
import { categorysSaga } from "./createCategory/categorySagas";
import { plantationSaga } from "./createPlantation/plantationSagas";
import { revanueSaga } from "./createRevanue/revanueSagas";
import stateSaga from "./createStateMaster/stateSagas";

export default function* rootSaga() {
  yield all([
    dummySagas(),
    authSagas(),
    toggleSaga(),
    auctionCenterRootSagas(),
    saleSagas(),
    teaType(),
    markData(),
    watchFetchWarehouseUser(),
    watchFetchGrade(),
    watchFetchCategory(),
    stateSaga(),
    allAuctionCenterSaga(),
    TeaTypesSaga(),
    gradeSagas(),
    factorysSagas(),
    subTeaTypesSaga(),
    roleSaga(),
    categorysSaga(),
    plantationSaga(),
    revanueSaga(),
  ]);
}
