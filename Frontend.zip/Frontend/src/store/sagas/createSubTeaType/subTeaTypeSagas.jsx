import { all, call, put, takeEvery } from "redux-saga/effects";
import axiosMain from "../../../http/axios/axios_main";
import {
  GET_ALL_SUB_TEA_TYPES,
  CREATE_SUB_TEA_TYPE,
  UPDATE_SUB_TEA_TYPE,
  SEARCH_SUB_TEA_TYPE,
  GET_SUB_TEA_TYPES_BY_STATUS,
  GET_SUB_TEA_TYPE_BY_ID,
} from "../../actionLabels";
import {
  getAllSubTeaTypes,
  getAllSubTeaTypesSuccess,
  getAllSubTeaTypesFail,
  createSubTeaTypeSuccess,
  createSubTeaTypeFail,
  updateSubTeaTypeSuccess,
  updateSubTeaTypeFail,
  searchSubTeaTypeSuccess,
  searchSubTeaTypeFail,
  getSubTeaTypesByStatusSuccess,
  getSubTeaTypesByStatusFail,
  getSubTeaTypeByIdSuccess,
  getSubTeaTypeByIdFail,
} from "../../actions";

// Sagas for getting all sub tea types
function* getAllSubTeaTypesSaga() {
  try {
    const subTeaTypes = yield call(axiosMain.get, `admin/subTeaType/getAll`);
    yield put(getAllSubTeaTypesSuccess(subTeaTypes.data));
  } catch (error) {
    yield put(getAllSubTeaTypesFail(error));
  }
}
// Sagas for creating a new sub tea type
function* createSubTeaTypeSaga(action) {
  try {
    const { subTeaTypeData } = action.payload;
    yield call(axiosMain.post, `admin/subTeaType/create`, subTeaTypeData);
    yield put(createSubTeaTypeSuccess());
    yield put(getAllSubTeaTypes());
  } catch (error) {
    yield put(createSubTeaTypeFail(error));
  }
}
// Sagas for updating a sub tea type
function* updateSubTeaTypeSaga(action) {
  try {
    const { updatedData } = action.payload;
    yield call(axiosMain.post, `admin/subTeaType/update`, updatedData);
    yield put(updateSubTeaTypeSuccess());
    yield put(getAllSubTeaTypes());
  } catch (error) {
    yield put(updateSubTeaTypeFail(error));
  }
}
// // Sagas for searching sub tea types based on criteria
// function* searchSubTeaTypeSaga(action) {
//   try {
//     const { searchCriteria } = action.payload;
//     const searchResults = yield call(api.searchSubTeaType, searchCriteria);
//     yield put(searchSubTeaTypeSuccess(searchResults));
//   } catch (error) {
//     yield put(searchSubTeaTypeFail(error));
//   }
// }
// // Sagas for getting sub tea types by status
// function* getSubTeaTypesByStatusSaga(action) {
//   try {
//     const { status } = action.payload;
//     const subTeaTypes = yield call(api.getSubTeaTypesByStatus, status);
//     yield put(getSubTeaTypesByStatusSuccess(subTeaTypes));
//   } catch (error) {
//     yield put(getSubTeaTypesByStatusFail(error));
//   }
// }
// Sagas for getting sub tea type by ID
function* getSubTeaTypeByIdSaga(action) {
  try {
    const { subTeaTypeId } = action.payload;
    const subTeaType = yield call(
      axiosMain.get,
      `admin/subTeaType/get/${subTeaTypeId}`
    );
    yield put(getSubTeaTypeByIdSuccess(subTeaType.data));
  } catch (error) {
    yield put(getSubTeaTypeByIdFail(error));
  }
}

export function* subTeaTypesSaga() {
  yield all([
    yield takeEvery(GET_ALL_SUB_TEA_TYPES, getAllSubTeaTypesSaga),
    yield takeEvery(CREATE_SUB_TEA_TYPE, createSubTeaTypeSaga),
    yield takeEvery(UPDATE_SUB_TEA_TYPE, updateSubTeaTypeSaga),
    // yield takeEvery(SEARCH_SUB_TEA_TYPE, searchSubTeaTypeSaga),
    // yield takeEvery(GET_SUB_TEA_TYPES_BY_STATUS, getSubTeaTypesByStatusSaga),
    yield takeEvery(GET_SUB_TEA_TYPE_BY_ID, getSubTeaTypeByIdSaga),
  ]);
}

export default subTeaTypesSaga;
