// commonSaga.js
import { takeLatest, put, call } from "redux-saga/effects";
import { fetchMarkSuccess, fetchMarkFailure } from "../../actions/index";
import axiosMain from "../../../http/axios/axios_main";
import { FETCH_MARK_REQUEST } from "../../actionLabels";

// Worker Saga: Makes the API call when the FETCH_MARK_REQUEST action is dispatched
function* fetchMarkSaga() {
  try {
    const response = yield call(axiosMain.get, "Common/BindMark");
    yield put(fetchMarkSuccess(response.data));
  } catch (error) {
    yield put(fetchMarkFailure(error.message));
  }
}

// Watcher Saga: Watches for the FETCH_MARK_REQUEST action and calls the worker saga
export function* markData() {
  yield takeLatest(FETCH_MARK_REQUEST, fetchMarkSaga);
}
