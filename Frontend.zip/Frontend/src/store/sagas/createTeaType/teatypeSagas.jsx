import { all, call, put, takeEvery } from "redux-saga/effects";
import axiosMain from "../../../http/axios/axios_main";
import {
  GET_ALL_TEA_TYPE,
  CREATE_TEA_TYPE,
  UPDATE_TEA_TYPE,
  SEARCH_TEA_TYPE,
  GET_TEA_TYPE_BY_STATUS,
  GET_TEA_TYPE_BY_ID,
} from "../../actionLabels";
import {
  getAllTeaTypes,
  getAllTeaTypesSuccess,
  getAllTeaTypesFail,
  createTeaTypeSuccess,
  createTeaTypeFail,
  updateTeaTypeSuccess,
  updateTeaTypeFail,
  searchTeaTypeSuccess,
  searchTeaTypeFail,
  getTeaTypesByStatusSuccess,
  getTeaTypesByStatusFail,
  getTeaTypeByIdSuccess,
  getTeaTypeByIdFail,
} from "../../actions";

// Worker saga for getting all tea types
function* getAllTeaTypesSaga() {
  try {
    const response = yield call(axiosMain.get, "admin/teaType/getAll");
    yield put(getAllTeaTypesSuccess(response.data));
  } catch (error) {
    yield put(getAllTeaTypesFail(error.message));
  }
}
// Worker saga for creating a new tea type
function* createTeaTypeSaga(action) {
  try {
    yield call(axiosMain.post, `admin/teaType/create`, action.payload);
    yield put(createTeaTypeSuccess());
    yield put(getAllTeaTypes());
    // Optionally, dispatch another action to handle any additional logic after successful creation
  } catch (error) {
    yield put(createTeaTypeFail(error.message));
  }
}
// Worker saga for updating a tea type
function* updateTeaTypeSaga(action) {
  try {
    yield call(
      axiosMain.post,
      `admin/teaType/update`,
      action.payload.updatedData
    );
    yield put(updateTeaTypeSuccess());
    yield put(getAllTeaTypes());
    // Optionally, dispatch another action to handle any additional logic after successful update
  } catch (error) {
    yield put(updateTeaTypeFail(error.message));
  }
}
// Worker saga for searching tea types
function* searchTeaTypeSaga(action) {
  try {
    const searchResults = yield call(
      axiosMain.get`/admin/teaType/getSearch/search/Teatype`,
      action.payload
    );
    yield put(searchTeaTypeSuccess(searchResults));
  } catch (error) {
    yield put(searchTeaTypeFail(error.message));
  }
}
// Worker saga for getting tea types by status
function* getTeaTypesByStatusSaga(action) {
  try {
    const teaTypes = yield call(
      axiosMain.get,
      `admin/teaType/getAll`,
      action.payload
    );
    yield put(getTeaTypesByStatusSuccess(teaTypes));
  } catch (error) {
    yield put(getTeaTypesByStatusFail(error.message));
  }
}

// Worker saga for getting a tea type by ID
function* getTeaTypeByIdSaga(action) {
  try {
    const teaType = yield call(
      axiosMain.get,
      `admin/teaType/get/${action.payload}`
    );
    yield put(getTeaTypeByIdSuccess(teaType.data));
  } catch (error) {
    yield put(getTeaTypeByIdFail(error.message));
  }
}
export function* TeaTypesSaga() {
  yield all([
    yield takeEvery(GET_ALL_TEA_TYPE, getAllTeaTypesSaga),
    yield takeEvery(CREATE_TEA_TYPE, createTeaTypeSaga),
    yield takeEvery(UPDATE_TEA_TYPE, updateTeaTypeSaga),
    yield takeEvery(SEARCH_TEA_TYPE, searchTeaTypeSaga),
    yield takeEvery(GET_TEA_TYPE_BY_STATUS, getTeaTypesByStatusSaga),
    yield takeEvery(GET_TEA_TYPE_BY_ID, getTeaTypeByIdSaga),
  ]);
}
