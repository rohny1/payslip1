import { all, call, put, takeEvery } from "redux-saga/effects";
import axiosMain from "../../../http/axios/axios_main";
import * as actionTypes from "../../actionLabels";
import {
  getAllAuctionCenterAction,
  getAllAuctionCenterActionSuccess,
  getAllAuctionCenterActionFail,
  updateAuctionCenterActionSuccess,
  updateAuctionCenterActionFail,
  createAuctionCenterActionSuccess,
  createAuctionCenterActionFail,
  searchAuctionCenterActionSuccess,
  searchAuctionCenterActionFail,
  getAuctionCenterByStatusActionSuccess,
  getAuctionCenterByStatusActionFail,
  getAuctionCenterByIdActionSuccess,
  getAuctionCenterByIdActionFail,
} from "../../actions";

function* getAllAuctionCenterSaga() {
  try {
    const response = yield call(axiosMain.get, `admin/auctionCenter/getAll`);
    yield put(getAllAuctionCenterActionSuccess(response.data));
    // console.log("responseSate:", response);
  } catch (error) {
    yield put(getAllAuctionCenterActionFail(error));
  }
}
// CREATE AUCTION CENTER
function* createAuctionCenter(action) {
  try {
    const createdAuctionCenter = yield call(
      axiosMain.post,
      `admin/auctionCenter/create`,
      action.payload
    );
    yield put(createAuctionCenterActionSuccess(createdAuctionCenter));
    yield put(getAllAuctionCenterAction());
  } catch (error) {
    yield put(createAuctionCenterActionFail(error));
  }
}
// UPDATE AUCTION CENTER
function* updateAuctionCenter(action) {
  console.log("updating data", action.payload);
  try {
    // const { updatedAuctionCenterData } = action.payload;
    const updatedAuctionCenter = yield call(
      axiosMain.post,
      `admin/auctionCenter/update`,
      action.payload
    );
    yield put(updateAuctionCenterActionSuccess(updatedAuctionCenter));
    yield put(getAllAuctionCenterAction());
  } catch (error) {
    yield put(updateAuctionCenterActionFail(error));
  }
}

// SEARCH AUCTION CENTER
function* searchAuctionCenter(action) {
  try {
    const searchResults = yield call(
      axiosMain.get,
      `admin/auctionCenter/search`,
      action.payload
    );
    yield put(searchAuctionCenterActionSuccess(searchResults));
  } catch (error) {
    yield put(searchAuctionCenterActionFail(error));
  }
}

// GET AUCTION CENTER BY STATUS
function* getAuctionCenterByStatus(action) {
  try {
    const auctionCenters = yield call(
      axiosMain.get,
      `admin/auctionCenter/getAll`,
      action.payload
    );
    yield put(getAuctionCenterByStatusActionSuccess(auctionCenters));
  } catch (error) {
    yield put(getAuctionCenterByStatusActionFail(error));
  }
}

// GET AUCTION CENTER BY ID
function* getAuctionCenterById(action) {
  console.log("getbyid", action.payload);
  try {
    const auctionCenter = yield call(
      axiosMain.get,
      `admin/auctionCenter/get/${action.payload}`
    );
    yield put(getAuctionCenterByIdActionSuccess(auctionCenter.data));
  } catch (error) {
    yield put(getAuctionCenterByIdActionFail(error));
  }
}

export function* allAuctionCenterSaga() {
  yield all([
    yield takeEvery(
      actionTypes.GET_ALL_AUCTION_CENTER,
      getAllAuctionCenterSaga
    ),
    yield takeEvery(actionTypes.CREATE_AUCTION_CENTER, createAuctionCenter),
    yield takeEvery(actionTypes.UPDATE_AUCTION_CENTER, updateAuctionCenter),
    yield takeEvery(actionTypes.SEARCH_AUCTION_CENTER, searchAuctionCenter),
    yield takeEvery(
      actionTypes.GET_AUCTION_CENTER_BY_STATUS,
      getAuctionCenterByStatus
    ),
    yield takeEvery(actionTypes.GET_AUCTION_CENTER_BY_ID, getAuctionCenterById),
  ]);
}
