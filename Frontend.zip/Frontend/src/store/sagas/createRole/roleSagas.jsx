import { all, call, put, takeEvery } from "redux-saga/effects";
import axiosMain from "../../../http/axios/axios_main";
import {
  GET_ALL_ROLES,
  CREATE_ROLE,
  UPDATE_ROLE,
  SEARCH_ROLE,
  GET_ROLE_BY_STATUS,
  GET_ROLE_BY_ID,
} from "../../actionLabels";
import {
  getAllRoles,
  getAllRolesSuccess,
  getAllRolesFail,
  createRoleSuccess,
  createRoleFail,
  updateRoleSuccess,
  updateRoleFail,
  searchRoleSuccess,
  searchRoleFail,
  getRolesByStatusSuccess,
  getRolesByStatusFail,
  getRoleByIdSuccess,
  getRoleByIdFail,
} from "../../actions";

// Worker function for getting all roles
function* getAllRolesSaga() {
  try {
    const response = yield call(axiosMain.get, "admin/role/get/AllRoles");
    yield put(getAllRolesSuccess(response.data));
  } catch (error) {
    yield put(getAllRolesFail(error));
  }
}
// Worker function for creating a new role
function* createRoleSaga(action) {
  try {
    const { roleData } = action.payload;
    yield call(axiosMain.post, `admin/role/create`, roleData);
    yield put(createRoleSuccess());
    yield put(getAllRoles());
  } catch (error) {
    yield put(createRoleFail(error));
  }
}
// Worker function for updating a role
function* updateRoleSaga(action) {
  try {
    const { updatedData } = action.payload;
    console.log("dta::", updatedData);
    yield call(axiosMain.post, `admin/role/update`, updatedData);

    yield put(updateRoleSuccess());
    yield put(getAllRoles());
  } catch (error) {
    yield put(updateRoleFail(error));
  }
}

// Worker function for searching roles based on criteria
// function* searchRoleSaga(action) {
//   try {
//     const { searchCriteria } = action.payload;
//     const response = yield call(api.searchRole, searchCriteria);
//     yield put(searchRoleSuccess(response.data));
//   } catch (error) {
//     yield put(searchRoleFail(error));
//   }
// }

// // Worker function for getting roles by status
// function* getRolesByStatusSaga(action) {
//   try {
//     const { status } = action.payload;
//     const response = yield call(api.getRolesByStatus, status);
//     yield put(getRolesByStatusSuccess(response.data));
//   } catch (error) {
//     yield put(getRolesByStatusFail(error));
//   }
// }

// Worker function for getting a role by ID
function* getRoleByIdSaga(action) {
  try {
    const { roleId } = action.payload;
    const response = yield call(axiosMain.get, `admin/role/get/${roleId}`);
    yield put(getRoleByIdSuccess(response.data));
  } catch (error) {
    yield put(getRoleByIdFail(error));
  }
}

export function* roleSaga() {
  yield all([
    yield takeEvery(GET_ALL_ROLES, getAllRolesSaga),
    yield takeEvery(CREATE_ROLE, createRoleSaga),
    yield takeEvery(UPDATE_ROLE, updateRoleSaga),
    // yield takeEvery(SEARCH_ROLE, searchRoleSaga),
    // yield takeEvery(GET_ROLE_BY_STATUS, getRolesByStatusSaga),
    yield takeEvery(GET_ROLE_BY_ID, getRoleByIdSaga),
  ]);
}
