export const LOGIN_SAGA = "LOGIN_SAGA";
export const LOGIN_SUCCESS = "LOGIN_SUCCESS";
export const LOGIN_FAIL = "LOGIN_FAIL";
