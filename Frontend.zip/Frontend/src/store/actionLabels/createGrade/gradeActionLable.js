// Get all grades
export const GET_ALL_GRADES = "GET_ALL_GRADES";
export const GET_ALL_GRADES_SUCCESS = "GET_ALL_GRADES_SUCCESS";
export const GET_ALL_GRADES_FAIL = "GET_ALL_GRADES_FAIL";

// Create grade
export const CREATE_GRADE = "CREATE_GRADE";
export const CREATE_GRADE_SUCCESS = "CREATE_GRADE_SUCCESS";
export const CREATE_GRADE_FAIL = "CREATE_GRADE_FAIL";

// Update grade
export const UPDATE_GRADE = "UPDATE_GRADE";
export const UPDATE_GRADE_SUCCESS = "UPDATE_GRADE_SUCCESS";
export const UPDATE_GRADE_FAIL = "UPDATE_GRADE_FAIL";

// Search grade
export const SEARCH_GRADE = "SEARCH_GRADE";
export const SEARCH_GRADE_SUCCESS = "SEARCH_GRADE_SUCCESS";
export const SEARCH_GRADE_FAIL = "SEARCH_GRADE_FAIL";

// Get grades by status
export const GET_GRADES_BY_STATUS = "GET_GRADES_BY_STATUS";
export const GET_GRADES_BY_STATUS_SUCCESS = "GET_GRADES_BY_STATUS_SUCCESS";
export const GET_GRADES_BY_STATUS_FAIL = "GET_GRADES_BY_STATUS_FAIL";

// Get grade by ID
export const GET_GRADE_BY_ID = "GET_GRADE_BY_ID";
export const GET_GRADE_BY_ID_SUCCESS = "GET_GRADE_BY_ID_SUCCESS";
export const GET_GRADE_BY_ID_FAIL = "GET_GRADE_BY_ID_FAIL";
