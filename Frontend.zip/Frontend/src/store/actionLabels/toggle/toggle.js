export const TOGGLE_SAGA = "TOGGLE_SAGA";
export const TOGGLE_SUCCESS = "TOGGLE_SUCCESS";
export const TOGGLE_FAIL = "TOGGLE_FAIL";
